package net.xcvb.totem;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.util.Identifier;

/**
 * Adds a rare chance for certain vanilla mobs to drop one of the XCVB totems on death.
 * Built entirely on Fabric API's LootTableEvents - no mixin involved here, so this part
 * cannot conflict with any other mod's item/entity logic.
 *
 * NOTE: a couple of entries below are our best guess for what you described - double
 * check the mob list against your message and tell me if anything needs swapping:
 *   - "الأخ الثاني أبو السيف" (medium tier) -> mapped to Evoker for now, since the exact
 *     illager you mean wasn't 100% clear (Pillager = crossbow, Vindicator = axe are the
 *     only other illager-family mobs). Tell me if you meant a different mob and I'll swap it.
 */
public class ModDrops {

    public static void register() {
        // --- Simple tier: common early-game mobs, 7% each ---
        addDrop(EntityType.ZOMBIE.getLootTableId(), ModItems.TOTEM_XCVB_SIMPLE, 0.07f);
        addDrop(EntityType.SKELETON.getLootTableId(), ModItems.TOTEM_XCVB_SIMPLE, 0.07f);
        addDrop(EntityType.SPIDER.getLootTableId(), ModItems.TOTEM_XCVB_SIMPLE, 0.07f);

        // --- Medium tier: tougher/rarer mobs, 7% each ---
        addDrop(EntityType.ENDERMAN.getLootTableId(), ModItems.TOTEM_XCVB_MEDIUM, 0.07f);
        addDrop(EntityType.WITHER_SKELETON.getLootTableId(), ModItems.TOTEM_XCVB_MEDIUM, 0.07f);
        addDrop(EntityType.PILLAGER.getLootTableId(), ModItems.TOTEM_XCVB_MEDIUM, 0.07f);
        addDrop(EntityType.EVOKER.getLootTableId(), ModItems.TOTEM_XCVB_MEDIUM, 0.07f); // see note above

        // --- Strong tier: end-game / boss-tier mobs, 7% each except Ghast which is rarer ---
        addDrop(EntityType.VINDICATOR.getLootTableId(), ModItems.TOTEM_XCVB_STRONG, 0.07f);
        addDrop(EntityType.WARDEN.getLootTableId(), ModItems.TOTEM_XCVB_STRONG, 0.07f);
        addDrop(EntityType.WITHER.getLootTableId(), ModItems.TOTEM_XCVB_STRONG, 0.07f);
        addDrop(EntityType.GHAST.getLootTableId(), ModItems.TOTEM_XCVB_STRONG, 0.02f); // kept low as requested
    }

    private static void addDrop(Identifier lootTableId, Item item, float chance) {
        LootTableEvents.MODIFY.register((resourceManager, manager, id, tableBuilder, source) -> {
            if (id.equals(lootTableId)) {
                tableBuilder.pool(LootPool.builder()
                        .with(ItemEntry.builder(item))
                        .conditionally(RandomChanceLootCondition.builder(chance))
                );
            }
        });
    }
}
