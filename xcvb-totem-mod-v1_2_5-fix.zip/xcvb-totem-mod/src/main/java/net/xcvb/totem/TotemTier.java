package net.xcvb.totem;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.List;

/**
 * The three power levels of the XCVB Totem.
 * Each tier grants longer and stronger effects than the one below it,
 * on top of the normal "totem of undying" death-cancelling behaviour.
 */
public enum TotemTier {

    // name, regenAmp, effectDurTicks, absorbAmp, fireResistTicks, invulnDurTicks, particleCount, particle, extraSound
    SIMPLE("totem_xcvb_simple", 1, 900, 0, 200, 100, 30, ParticleTypes.END_ROD, SoundEvents.BLOCK_BEACON_ACTIVATE),
    MEDIUM("totem_xcvb_medium", 2, 1600, 1, 400, 140, 45, ParticleTypes.SOUL_FIRE_FLAME, SoundEvents.ENTITY_EVOKER_CAST_SPELL),
    STRONG("totem_xcvb_strong", 3, 2400, 2, 600, 200, 60, ParticleTypes.DRAGON_BREATH, SoundEvents.ENTITY_ENDER_DRAGON_GROWL);

    public final String itemId;
    private final int regenAmplifier;
    private final int effectDurationTicks;
    private final int absorptionAmplifier;
    private final int fireResistanceDurationTicks;
    private final int invulnerabilityDurationTicks;
    private final int particleCount;
    private final ParticleEffect particle;
    private final SoundEvent extraSound;

    TotemTier(String itemId, int regenAmplifier, int effectDurationTicks, int absorptionAmplifier,
              int fireResistanceDurationTicks, int invulnerabilityDurationTicks,
              int particleCount, ParticleEffect particle, SoundEvent extraSound) {
        this.itemId = itemId;
        this.regenAmplifier = regenAmplifier;
        this.effectDurationTicks = effectDurationTicks;
        this.absorptionAmplifier = absorptionAmplifier;
        this.fireResistanceDurationTicks = fireResistanceDurationTicks;
        this.invulnerabilityDurationTicks = invulnerabilityDurationTicks;
        this.particleCount = particleCount;
        this.particle = particle;
        this.extraSound = extraSound;
    }

    public int getParticleCount() {
        return particleCount;
    }

    public ParticleEffect getParticle() {
        return particle;
    }

    /** Extra sound layered on top of the normal totem sound. Null for tiers that don't have one. */
    public SoundEvent getExtraSound() {
        return extraSound;
    }

    /**
     * The status effects applied to the player the instant this tier of totem saves them from death.
     * Resistance V (amplifier 4) blocks essentially all incoming damage for its duration - that's the
     * "near-invulnerability" window right after the totem pops, on top of regen/absorption/fire resist.
     */
    public List<StatusEffectInstance> getEffects() {
        return List.of(
                new StatusEffectInstance(StatusEffects.REGENERATION, effectDurationTicks, regenAmplifier, false, true, true),
                new StatusEffectInstance(StatusEffects.ABSORPTION, effectDurationTicks, absorptionAmplifier, false, true, true),
                new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, fireResistanceDurationTicks, 0, false, true, true),
                new StatusEffectInstance(StatusEffects.RESISTANCE, invulnerabilityDurationTicks, 4, false, true, true)
        );
    }

    public static TotemTier next(TotemTier tier) {
        return switch (tier) {
            case SIMPLE -> MEDIUM;
            case MEDIUM -> STRONG;
            case STRONG -> STRONG;
        };
    }
}
