package net.xcvb.totem;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;

/**
 * Adds a chance for each of the three XCVB totems to drop from specific vanilla mobs
 * when they die, on top of their normal drops.
 *
 * This uses Fabric API's LootTableEvents.MODIFY hook (rather than overwriting the vanilla
 * loot table JSON files directly), so it only *adds* a pool to the existing table instead
 * of replacing it - safe to run alongside other mods/datapacks that also touch these tables.
 */
public class ModLootTables {

    // Simple tier: common early-game mobs
    private static final float SIMPLE_CHANCE = 0.08F; // 8%
    // Medium tier: tougher / rarer mobs
    private static final float MEDIUM_CHANCE = 0.06F; // 6%
    // Strong tier: late-game / boss-tier mobs
    private static final float STRONG_CHANCE = 0.05F; // 5%
    // Elder Guardian specifically requested at a lower rate than the rest of its tier
    private static final float ELDER_GUARDIAN_CHANCE = 0.03F; // 3%

    public static void register() {
        addDrop(EntityType.ZOMBIE, ModItems.TOTEM_XCVB_SIMPLE, SIMPLE_CHANCE);
        addDrop(EntityType.SKELETON, ModItems.TOTEM_XCVB_SIMPLE, SIMPLE_CHANCE);
        addDrop(EntityType.SPIDER, ModItems.TOTEM_XCVB_SIMPLE, SIMPLE_CHANCE);

        addDrop(EntityType.ENDERMAN, ModItems.TOTEM_XCVB_MEDIUM, MEDIUM_CHANCE);
        addDrop(EntityType.WITHER_SKELETON, ModItems.TOTEM_XCVB_MEDIUM, MEDIUM_CHANCE);
        addDrop(EntityType.PILLAGER, ModItems.TOTEM_XCVB_MEDIUM, MEDIUM_CHANCE);       // "أبو الكروسبو"
        addDrop(EntityType.VINDICATOR, ModItems.TOTEM_XCVB_MEDIUM, MEDIUM_CHANCE);     // "أبو السيف"

        addDrop(EntityType.PIGLIN_BRUTE, ModItems.TOTEM_XCVB_STRONG, STRONG_CHANCE);   // "أبو الفاس"
        addDrop(EntityType.WARDEN, ModItems.TOTEM_XCVB_STRONG, STRONG_CHANCE);
        addDrop(EntityType.WITHER, ModItems.TOTEM_XCVB_STRONG, STRONG_CHANCE);
        addDrop(EntityType.ELDER_GUARDIAN, ModItems.TOTEM_XCVB_STRONG, ELDER_GUARDIAN_CHANCE); // "الگارديان" - lower rate as requested
    }

    private static void addDrop(EntityType<?> entityType, Item item, float chance) {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (!source.isBuiltin()) return;
            if (id.equals(entityType.getLootTableId())) {
                LootPool.Builder pool = LootPool.builder()
                        .rolls(ConstantLootNumberProvider.create(1))
                        .with(ItemEntry.builder(item))
                        .conditionally(RandomChanceLootCondition.builder(chance));
                tableBuilder.pool(pool);
            }
        });
    }
}
