# XCVB Totem Mod (Fabric 1.21.1)

Adds three craftable tiers of a custom "XCVB" totem: Simple, Medium, Strong.
Holding one in your main or off hand saves you from death exactly like the
vanilla Totem of Undying, but each tier grants longer and stronger effects
(Regeneration, Absorption, Fire Resistance) than the one before it. Implemented
via a single, narrow mixin into `LivingEntity#tryUseTotem` that only activates
when you're holding one of these three items — it does not touch or override
any vanilla item, so it should not conflict with other mods unless they also
mixin into that exact method.

## Recipes
- **Simple**: 4 Gold Ingots + 1 Emerald (shapeless) — no vanilla Totem of Undying needed
- **Medium**: 1 Simple totem + 4 Diamonds (shapeless)
- **Strong**: 1 Medium totem + 2 Nether Stars + 2 Diamond Blocks (shapeless)

## Effects on trigger
| Tier   | Regeneration       | Absorption | Fire Resistance |
|--------|--------------------|------------|------------------|
| Simple | II, 45s            | I          | 10s              |
| Medium | III, 80s           | II         | 20s              |
| Strong | IV, 120s           | III        | 30s              |

All values are in `TotemTier.java` — change the numbers there to rebalance.

## How to build (I can't compile this myself — no internet access in my sandbox)
You need a PC with internet and **JDK 21** installed.

1. Unzip this project.
2. Open a terminal in the project folder.
3. If you don't already have Gradle installed, install it once, then run:
   ```
   gradle wrapper --gradle-version 8.8
   ```
   (this generates `gradlew` / `gradlew.bat` — only needs to be done once)
4. Build the mod:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
5. The finished jar appears in `build/libs/xcvb-totem-mod-1.0.0.jar`.

Alternatively, open the folder directly in **IntelliJ IDEA** with the Gradle
plugin — it will detect `build.gradle` and offer to import/build it for you
with no manual Gradle install needed.

## Install
1. Make sure the server (and every client, since this changes client-visible
   items) is running **Fabric Loader 0.16.9+** on **Minecraft 1.21.1**.
2. Install **Fabric API 0.115.0+1.21.1** as well (it's a dependency).
3. Drop the built jar into the `mods` folder.
4. Restart the server/client.

⚠️ Note: your existing self-hosted server (from our earlier conversations) was
set up on **Fabric 1.20.1**. This mod is targeted at **1.21.1** as you
requested — it will not load on the 1.20.1 server unless you update that
server to 1.21.1 (which would also require updating any other 1.20.1-only
mods you have installed there).

## Custom textures
Placeholder 16x16 icons are included (green/blue/purple) so the items don't
look like question marks — swap the PNGs in
`src/main/resources/assets/xcvbtotem/textures/item/` with your own art anytime,
no code changes needed.

## Update: sound + particles + near-invulnerability (v1.1)
On top of the original effects, activating any XCVB totem now also:
- Spawns a burst of particles around you (Simple = End Rod, Medium = Soul Fire Flame, Strong = Dragon Breath, bigger burst per tier)
- Strong tier also plays an extra low Ender Dragon growl layered on top of the totem sound
- Grants **Resistance V** for a few seconds (Simple 5s / Medium 7s / Strong 10s) — blocks almost all incoming damage right after you're saved, on top of Regeneration/Absorption/Fire Resistance

## Update: mob drops (v1.2)
Each totem can now also drop directly from killing specific mobs (in addition to crafting):

| Tier   | Mobs                                                    | Drop chance |
|--------|----------------------------------------------------------|-------------|
| Simple | Zombie, Skeleton, Spider                                 | 8% each     |
| Medium | Enderman, Wither Skeleton, Pillager, Vindicator           | 6% each     |
| Strong | Piglin Brute, Warden, Wither                              | 5% each     |
| Strong | Elder Guardian                                            | 3% (lower, as requested) |

Implemented via Fabric API's `LootTableEvents.MODIFY` in `ModLootTables.java`, which *adds*
a chance-based pool to each mob's existing loot table instead of overwriting the table file -
this is the safe way to do it so it won't conflict with other mods/datapacks that also touch
these same loot tables.

⚠️ **Heads up**: this is the one part of the mod I'm least certain compiles cleanly on the first
try without testing against the real 1.21.1 libraries (the loot table / registry API changed a lot
around this version). If `./gradlew build` (or your GitHub Actions / Replit build) fails specifically
on `ModLootTables.java`, just paste me the error message and I'll fix it immediately - everything else
in the mod (items, effects, mixin) is unaffected by this and already confirmed working in your last build.

## Update v1.2.4: rare mob drops + grander pop effect
- Each XCVB totem now has a small chance to drop from certain mobs on death (added via
  Fabric API's loot table event - no mixin, so this addition specifically can't conflict
  with other mods):
  - **Simple (7% each):** Zombie, Skeleton, Spider
  - **Medium (7% each):** Enderman, Wither Skeleton, Pillager, Evoker *(best guess for the
    "second sword brother" you mentioned - tell me if you meant a different illager and
    I'll swap it in `ModDrops.java`)*
  - **Strong:** Vindicator 7%, Warden 7%, Wither 7%, **Ghast 2%** (kept low as requested)
- Every tier now plays its own extra "grand" sound on trigger (Simple = beacon activation
  chime, Medium = evoker cast, Strong = dragon growl - unchanged)
- Added a burst of particles rendering **your actual totem's icon** flying around the
  player on trigger, on top of the tier-colored particle effect. Note: the small vanilla
  "totem pop" icon that flashes on screen is a deeply built-in client visual I can't fully
  verify overriding without direct access to decompiled 1.21.1 code (no internet in my
  sandbox) - the new item-icon particle burst is the reliable way your custom look shows.
  If you find the exact class/method to redirect that icon, send me the compile error and
  I'll wire it in properly.

## Update v1.2.4b: auto-refill
If a totem triggers and empties your hand slot, the mod now automatically checks your
inventory for another totem of the SAME tier and moves one straight into that hand slot -
no need to manually re-equip after a save.

## Fix v1.2.4c: recipes weren't loading
Minecraft 1.21 renamed several data pack folders to plural form as part of a pack format
reorganization. Recipes moved from `data/<namespace>/recipe/` to `data/<namespace>/recipes/`.
This project's recipe files were still in the old singular folder, so the game silently
ignored them (the item existed and worked fine, but crafting produced nothing). Fixed by
moving all three recipe JSONs to `data/xcvbtotem/recipes/`.
