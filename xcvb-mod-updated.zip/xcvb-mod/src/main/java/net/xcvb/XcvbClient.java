package net.xcvb;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.xcvb.ring.ModScreenHandlers;
import net.xcvb.ring.RingCaseScreen;
import net.xcvb.rune.RuneTooltipHandler;

/**
 * نقطة بداية خاصة بالعميل (Client) بس - عشان أشياء زي الـ Tooltip والشاشات ما تحاول تحمل
 * كلاسات خاصة بالعميل على السيرفر المخصص (Dedicated Server) وتسبب كراش.
 */
public class XcvbClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		RuneTooltipHandler.register();
		HandledScreens.register(ModScreenHandlers.RING_CASE_SCREEN_HANDLER, RingCaseScreen::new);
	}
}
