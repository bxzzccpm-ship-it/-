package net.xcvb.rune;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class RuneTooltipHandler {

	public static void register() {
		ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
			RuneType rune = RuneData.getRune(stack);
			if (rune != null) {
				lines.add(Text.translatable("xcvb.rune.tooltip." + rune.name().toLowerCase()).formatted(Formatting.LIGHT_PURPLE));
			}
		});
	}
}
