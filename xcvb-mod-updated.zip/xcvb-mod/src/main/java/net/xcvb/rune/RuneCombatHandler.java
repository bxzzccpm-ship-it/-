package net.xcvb.rune;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Random;

public class RuneCombatHandler {

	private static final Random RANDOM = new Random();

	public static void register() {
		AttackEntityCallback.EVENT.register(RuneCombatHandler::onAttack);
	}

	private static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity target, net.minecraft.util.hit.EntityHitResult hitResult) {
		if (world.isClient) return ActionResult.PASS;
		if (!(target instanceof LivingEntity living)) return ActionResult.PASS;
		if (!(player instanceof ServerPlayerEntity)) return ActionResult.PASS;

		ItemStack weapon = player.getStackInHand(hand);
		RuneType rune = RuneData.getRune(weapon);
		if (rune == null) return ActionResult.PASS;

		if (RANDOM.nextFloat() > rune.procChance) return ActionResult.PASS;

		ServerWorld serverWorld = (ServerWorld) world;

		switch (rune) {
			case VOID -> {
				living.damage(serverWorld, world.getDamageSources().magic(), 4.0F);
				serverWorld.spawnParticles(ParticleTypes.REVERSE_PORTAL, living.getX(), living.getY() + 1, living.getZ(), 20, 0.3, 0.5, 0.3, 0.02);
			}
			case STORM -> {
				LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(serverWorld);
				if (lightning != null) {
					lightning.refreshPositionAfterTeleport(Vec3d.ofBottomCenter(living.getBlockPos()));
					serverWorld.spawnEntity(lightning);
				}
			}
			case FROST -> {
				living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 3));
				living.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 80, 1));
				serverWorld.spawnParticles(ParticleTypes.SNOWFLAKE, living.getX(), living.getY() + 1, living.getZ(), 20, 0.3, 0.5, 0.3, 0.02);
			}
			case FLAME -> {
				living.setFireTicks(100);
				serverWorld.spawnParticles(ParticleTypes.FLAME, living.getX(), living.getY() + 1, living.getZ(), 15, 0.3, 0.5, 0.3, 0.02);
			}
		}

		return ActionResult.PASS;
	}
}
