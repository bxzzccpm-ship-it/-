package net.xcvb.rune;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/**
 * يخزن/يقرأ نوع الرون المطبّق على أي ItemStack عبر Custom Data Component
 * (نفس الطريقة الرسمية بـ 1.21+ لتخزين بيانات مود بأي عنصر بدون تعريف Component خاص).
 */
public class RuneData {

	private static final String KEY = "xcvb_rune";

	public static void setRune(ItemStack stack, RuneType type) {
		NbtCompound nbt = new NbtCompound();
		nbt.putString(KEY, type.name());
		stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
	}

	public static RuneType getRune(ItemStack stack) {
		NbtComponent component = stack.get(DataComponentTypes.CUSTOM_DATA);
		if (component == null) return null;

		NbtCompound nbt = component.copyNbt();
		if (!nbt.contains(KEY)) return null;

		try {
			return RuneType.valueOf(nbt.getString(KEY));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static boolean hasRune(ItemStack stack) {
		return getRune(stack) != null;
	}
}
