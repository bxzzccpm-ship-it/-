package net.xcvb.rune;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * عنصر الرون: امسكه بيدك الأولى، وامسك أي سلاح عادي (سيف/فأس/بلطة...) باليد الثانية (Offhand)
 * واضغط يمين -> يتسحر السلاح بقدرة الرون بشكل دائم. الرون يُستهلك عند الاستخدام.
 * السلاح المسحور يشتغل تلقائيًا: كل ما تضرب فيه، فيه احتمال تتفعل قدرة الرون.
 */
public class RuneItem extends Item {

	private final RuneType type;

	public RuneItem(RuneType type, Settings settings) {
		super(settings);
		this.type = type;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack runeStack = user.getStackInHand(hand);
		Hand otherHand = (hand == Hand.MAIN_HAND) ? Hand.OFF_HAND : Hand.MAIN_HAND;
		ItemStack weapon = user.getStackInHand(otherHand);

		if (weapon.isEmpty() || !isImbuable(weapon)) {
			user.sendMessage(Text.translatable("xcvb.rune.need_weapon_other_hand").formatted(Formatting.RED), true);
			return TypedActionResult.fail(runeStack);
		}

		if (RuneData.hasRune(weapon)) {
			user.sendMessage(Text.translatable("xcvb.rune.already_imbued").formatted(Formatting.RED), true);
			return TypedActionResult.fail(runeStack);
		}

		RuneData.setRune(weapon, type);

		if (world instanceof ServerWorld serverWorld) {
			serverWorld.spawnParticles(ParticleTypes.ENCHANT, user.getX(), user.getY() + 1, user.getZ(), 40, 0.4, 0.6, 0.4, 0.05);
		}
		world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.PLAYERS, 1.0F, 1.0F);
		user.sendMessage(Text.translatable("xcvb.rune.imbued_success").formatted(Formatting.LIGHT_PURPLE), true);

		if (!user.getAbilities().creativeMode) {
			runeStack.decrement(1);
		}

		return TypedActionResult.success(runeStack, world.isClient());
	}

	private boolean isImbuable(ItemStack stack) {
		Item item = stack.getItem();
		return item instanceof SwordItem || item instanceof AxeItem
				|| item instanceof PickaxeItem || item instanceof ShovelItem || item instanceof HoeItem
				|| item instanceof net.xcvb.item.VoidBladeItem;
	}
}
