package net.xcvb.rune;

/**
 * أنواع الرونات - كل نوع يعطي قدرة مختلفة تشتغل تلقائيًا عند الضرب بالسلاح المسحور فيه.
 */
public enum RuneType {
	VOID("rune_of_the_void", 0.25F),   // ضربة صدى إضافية (ضرر حقيقي إضافي)
	STORM("rune_of_storms", 0.20F),    // صاعقة على الهدف
	FROST("rune_of_frost", 0.25F),     // تجميد الهدف
	FLAME("rune_of_flames", 0.30F);    // إشعال الهدف

	public final String id;
	public final float procChance; // احتمال تفعيل القدرة بكل ضربة

	RuneType(String id, float procChance) {
		this.id = id;
		this.procChance = procChance;
	}
}
