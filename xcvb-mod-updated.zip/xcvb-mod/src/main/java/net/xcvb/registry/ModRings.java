package net.xcvb.registry;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.xcvb.Xcvb;
import net.xcvb.ring.RingCaseItem;
import net.xcvb.ring.RingItem;
import net.xcvb.ring.RingType;

public class ModRings {

	public static final Item RING_CASE = register("ring_case",
			new RingCaseItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC)));

	public static final Item RING_OF_STRENGTH = register("ring_of_strength",
			new RingItem(RingType.STRENGTH, new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));
	public static final Item RING_OF_HASTE = register("ring_of_haste",
			new RingItem(RingType.HASTE, new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));
	public static final Item RING_OF_THE_FEATHER = register("ring_of_the_feather",
			new RingItem(RingType.FEATHER, new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));
	public static final Item RING_OF_REGROWTH = register("ring_of_regrowth",
			new RingItem(RingType.REGROWTH, new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));
	public static final Item RING_OF_SWIFTNESS = register("ring_of_swiftness",
			new RingItem(RingType.SWIFTNESS, new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name), item);
	}

	public static void registerRings() {
		Xcvb.LOGGER.info("XCVB: تسجيل الحلقات وعلبة الحلقات");
	}
}
