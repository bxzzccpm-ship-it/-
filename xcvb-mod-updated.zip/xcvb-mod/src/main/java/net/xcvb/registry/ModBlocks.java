package net.xcvb.registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

public class ModBlocks {

	public static final Block ARCANITE_ORE = registerBlock("arcanite_ore",
			new Block(FabricBlockSettings.create()
					.mapColor(MapColor.PURPLE)
					.strength(4.0F, 6.0F)
					.requiresTool()
					.sounds(BlockSoundGroup.DEEPSLATE)));

	public static final Block DEEPSLATE_ARCANITE_ORE = registerBlock("deepslate_arcanite_ore",
			new Block(FabricBlockSettings.create()
					.mapColor(MapColor.DEEPSLATE_GRAY)
					.strength(5.5F, 6.0F)
					.requiresTool()
					.sounds(BlockSoundGroup.DEEPSLATE)));

	public static final Block ARCANITE_BLOCK = registerBlock("arcanite_block",
			new Block(FabricBlockSettings.create()
					.mapColor(MapColor.PURPLE)
					.strength(6.0F, 8.0F)
					.requiresTool()
					.sounds(BlockSoundGroup.NETHERITE)));

	public static final Block ARCANE_ALTAR = registerBlock("arcane_altar",
			new net.xcvb.altar.ArcaneAltarBlock(FabricBlockSettings.create()
					.mapColor(MapColor.PURPLE)
					.strength(3.5F, 6.0F)
					.sounds(BlockSoundGroup.AMETHYST_CLUSTER)
					.luminance(state -> 5)));

	private static Block registerBlock(String name, Block block) {
		registerBlockItem(name, block);
		return Registry.register(Registries.BLOCK, Identifier.of(Xcvb.MOD_ID, name), block);
	}

	private static Item registerBlockItem(String name, Block block) {
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name),
				new BlockItem(block, new Item.Settings()));
	}

	public static void registerBlocks() {
		Xcvb.LOGGER.info("XCVB: تسجيل البلوكات");
	}
}
