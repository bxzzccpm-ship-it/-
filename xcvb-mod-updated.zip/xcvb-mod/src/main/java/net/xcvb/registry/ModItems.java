package net.xcvb.registry;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.xcvb.Xcvb;
import net.xcvb.item.AmuletOfVitalityItem;
import net.xcvb.item.StaffOfStormsItem;
import net.xcvb.item.VoidBladeItem;
import net.xcvb.item.WandOfTeleportationItem;

public class ModItems {

	// المادة الخام السحرية - تنكرت من Arcanite Ore
	public static final Item ARCANITE_INGOT = registerItem("arcanite_ingot",
			new Item(new FabricItemSettings().rarity(Rarity.UNCOMMON)));

	// السيف السحري - Blink Strike (يستخدم إحصائيات النذرايت + قدرة خاصة)
	public static final Item VOID_BLADE = registerItem("void_blade",
			new VoidBladeItem(ToolMaterials.NETHERITE, 4, -2.4F,
					new FabricItemSettings().rarity(Rarity.EPIC).maxCount(1)));

	// عصا العواصف - صاعقة عن بعد
	public static final Item STAFF_OF_STORMS = registerItem("staff_of_storms",
			new StaffOfStormsItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC)));

	// عصا التنقل السحرية
	public static final Item WAND_OF_TELEPORTATION = registerItem("wand_of_teleportation",
			new WandOfTeleportationItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));

	// تعويذة الحيوية - شفاء تلقائي
	public static final Item AMULET_OF_VITALITY = registerItem("amulet_of_vitality",
			new AmuletOfVitalityItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));

	// ===================== أدوات التعدين (Tools) =====================
	public static final Item ARCANITE_PICKAXE = registerItem("arcanite_pickaxe",
			new net.xcvb.item.ArcanitePickaxeItem(ToolMaterials.NETHERITE, 1, -2.8F,
					new FabricItemSettings()));

	public static final Item ARCANITE_AXE = registerItem("arcanite_axe",
			new net.xcvb.item.ArcaniteAxeItem(ToolMaterials.NETHERITE, 6.0F, -3.1F,
					new FabricItemSettings()));

	public static final Item ARCANITE_SHOVEL = registerItem("arcanite_shovel",
			new net.xcvb.item.ArcaniteShovelItem(ToolMaterials.NETHERITE, 1.5F, -3.0F,
					new FabricItemSettings()));

	public static final Item ARCANITE_HOE = registerItem("arcanite_hoe",
			new net.xcvb.item.ArcaniteHoeItem(ToolMaterials.NETHERITE, -2.0F, -1.0F,
					new FabricItemSettings()));

	// ===================== الدروع (Armor Set) - مادة مخصصة "arcanite" =====================
	public static final Item ARCANITE_HELMET = registerItem("arcanite_helmet",
			new net.minecraft.item.ArmorItem(ModArmorMaterials.ARCANITE,
					net.minecraft.item.ArmorItem.Type.HELMET, new FabricItemSettings().rarity(Rarity.RARE)));

	public static final Item ARCANITE_CHESTPLATE = registerItem("arcanite_chestplate",
			new net.minecraft.item.ArmorItem(ModArmorMaterials.ARCANITE,
					net.minecraft.item.ArmorItem.Type.CHESTPLATE, new FabricItemSettings().rarity(Rarity.RARE)));

	public static final Item ARCANITE_LEGGINGS = registerItem("arcanite_leggings",
			new net.minecraft.item.ArmorItem(ModArmorMaterials.ARCANITE,
					net.minecraft.item.ArmorItem.Type.LEGGINGS, new FabricItemSettings().rarity(Rarity.RARE)));

	public static final Item ARCANITE_BOOTS = registerItem("arcanite_boots",
			new net.minecraft.item.ArmorItem(ModArmorMaterials.ARCANITE,
					net.minecraft.item.ArmorItem.Type.BOOTS, new FabricItemSettings().rarity(Rarity.RARE)));

	// ===================== أسلحة سحرية إضافية =====================
	public static final Item FROST_WAND = registerItem("frost_wand",
			new net.xcvb.item.FrostWandItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));

	public static final Item METEOR_HAMMER = registerItem("meteor_hammer",
			new net.xcvb.item.MeteorHammerItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC)));

	public static final Item FIRE_SCROLL = registerItem("fire_scroll",
			new net.xcvb.item.FireScrollItem(new FabricItemSettings().rarity(Rarity.UNCOMMON)));

	// ===================== أكل ومواد =====================
	public static final Item ARCANE_BERRIES = registerItem("arcane_berries",
			new Item(new FabricItemSettings().food(new net.minecraft.component.type.FoodComponent.Builder()
					.nutrition(4).saturationModifier(0.3F)
					.statusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
							net.minecraft.entity.effect.StatusEffects.REGENERATION, 100, 1), 1.0F)
					.build())));

	private static Item registerItem(String name, Item item) {
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name), item);
	}

	public static void registerItems() {
		Xcvb.LOGGER.info("XCVB: تسجيل العناصر");
	}
}
