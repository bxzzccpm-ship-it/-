package net.xcvb.registry;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

public class ModItemGroups {

	public static final ItemGroup XCVB_GROUP = Registry.register(Registries.ITEM_GROUP,
			Identifier.of(Xcvb.MOD_ID, "xcvb_group"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(ModItems.VOID_BLADE))
					.displayName(Text.translatable("itemgroup.xcvb.xcvb_group"))
					.entries((displayContext, entries) -> {
						entries.add(ModItems.ARCANITE_INGOT);
						entries.add(ModBlocks.ARCANITE_ORE);
						entries.add(ModBlocks.DEEPSLATE_ARCANITE_ORE);
						entries.add(ModBlocks.ARCANITE_BLOCK);
						entries.add(ModItems.ARCANE_BERRIES);

						entries.add(ModItems.VOID_BLADE);
						entries.add(ModItems.STAFF_OF_STORMS);
						entries.add(ModItems.WAND_OF_TELEPORTATION);
						entries.add(ModItems.FROST_WAND);
						entries.add(ModItems.METEOR_HAMMER);
						entries.add(ModItems.FIRE_SCROLL);
						entries.add(ModItems.AMULET_OF_VITALITY);

						entries.add(ModItems.ARCANITE_PICKAXE);
						entries.add(ModItems.ARCANITE_AXE);
						entries.add(ModItems.ARCANITE_SHOVEL);
						entries.add(ModItems.ARCANITE_HOE);

						entries.add(ModItems.ARCANITE_HELMET);
						entries.add(ModItems.ARCANITE_CHESTPLATE);
						entries.add(ModItems.ARCANITE_LEGGINGS);
						entries.add(ModItems.ARCANITE_BOOTS);

						entries.add(ModBlocks.ARCANE_ALTAR);

						entries.add(ModRunes.RUNE_OF_THE_VOID);
						entries.add(ModRunes.RUNE_OF_STORMS);
						entries.add(ModRunes.RUNE_OF_FROST);
						entries.add(ModRunes.RUNE_OF_FLAMES);

						entries.add(ModRings.RING_CASE);
						entries.add(ModRings.RING_OF_STRENGTH);
						entries.add(ModRings.RING_OF_HASTE);
						entries.add(ModRings.RING_OF_THE_FEATHER);
						entries.add(ModRings.RING_OF_REGROWTH);
						entries.add(ModRings.RING_OF_SWIFTNESS);

						// ===== سلسلة التقدم: معادن + سبائك + أدوات =====
						entries.add(net.xcvb.progression.ModOreBlocks.SOUL_ORE);
						entries.add(net.xcvb.progression.ModOreBlocks.CRYSTAL_ORE);
						entries.add(net.xcvb.progression.ModOreBlocks.BLOOD_ORE);
						entries.add(net.xcvb.progression.ModOreBlocks.ENERGY_ORE);

						entries.add(net.xcvb.progression.ModProgressionItems.RAW_SOUL);
						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_INGOT);
						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_GEM);
						entries.add(net.xcvb.progression.ModProgressionItems.BLOOD_SHARD);
						entries.add(net.xcvb.progression.ModProgressionItems.ENERGY_CELL);
						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_INGOT);
						entries.add(net.xcvb.progression.ModProgressionItems.VOID_INGOT);

						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_PICKAXE);
						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_AXE);
						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_SHOVEL);
						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_HOE);
						entries.add(net.xcvb.progression.ModProgressionItems.CRYSTAL_SWORD);

						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_PICKAXE);
						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_AXE);
						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_SHOVEL);
						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_HOE);
						entries.add(net.xcvb.progression.ModProgressionItems.SOUL_SWORD);

						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_PICKAXE);
						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_AXE);
						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_SHOVEL);
						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_HOE);
						entries.add(net.xcvb.progression.ModProgressionItems.ANCIENT_SWORD);

						entries.add(net.xcvb.progression.ModProgressionItems.VOID_PICKAXE);
						entries.add(net.xcvb.progression.ModProgressionItems.VOID_AXE);
						entries.add(net.xcvb.progression.ModProgressionItems.VOID_SHOVEL);
						entries.add(net.xcvb.progression.ModProgressionItems.VOID_HOE);
						entries.add(net.xcvb.progression.ModProgressionItems.VOID_SWORD);

						// ===== الدروع الجديدة =====
						entries.add(net.xcvb.progression.ModProgressionArmor.SOUL_HELMET);
						entries.add(net.xcvb.progression.ModProgressionArmor.SOUL_CHESTPLATE);
						entries.add(net.xcvb.progression.ModProgressionArmor.SOUL_LEGGINGS);
						entries.add(net.xcvb.progression.ModProgressionArmor.SOUL_BOOTS);

						entries.add(net.xcvb.progression.ModProgressionArmor.ELECTRIC_HELMET);
						entries.add(net.xcvb.progression.ModProgressionArmor.ELECTRIC_CHESTPLATE);
						entries.add(net.xcvb.progression.ModProgressionArmor.ELECTRIC_LEGGINGS);
						entries.add(net.xcvb.progression.ModProgressionArmor.ELECTRIC_BOOTS);

						entries.add(net.xcvb.progression.ModProgressionArmor.ICE_HELMET);
						entries.add(net.xcvb.progression.ModProgressionArmor.ICE_CHESTPLATE);
						entries.add(net.xcvb.progression.ModProgressionArmor.ICE_LEGGINGS);
						entries.add(net.xcvb.progression.ModProgressionArmor.ICE_BOOTS);

						entries.add(net.xcvb.progression.ModProgressionArmor.VOID_HELMET);
						entries.add(net.xcvb.progression.ModProgressionArmor.VOID_CHESTPLATE);
						entries.add(net.xcvb.progression.ModProgressionArmor.VOID_LEGGINGS);
						entries.add(net.xcvb.progression.ModProgressionArmor.VOID_BOOTS);

						// ===== النباتات =====
						entries.add(net.xcvb.plant.ModPlantBlocks.GHOST_FLOWER);
						entries.add(net.xcvb.plant.ModPlantBlocks.FIRE_HERB);
						entries.add(net.xcvb.plant.ModPlantBlocks.MANA_LEAF);
						entries.add(net.xcvb.plant.ModPlantBlocks.CRYSTAL_LOG);
						entries.add(net.xcvb.plant.ModPlantBlocks.CRYSTAL_LEAVES);

						// ===== الآلات =====
						entries.add(net.xcvb.machine.ModMachineBlocks.SOUL_REACTOR);
						entries.add(net.xcvb.machine.ModMachineBlocks.GHOST_BATTERY);
						entries.add(net.xcvb.machine.ModMachineBlocks.CRYSTAL_COMPUTER);
					})
					.build());

	public static void registerItemGroups() {
		Xcvb.LOGGER.info("XCVB: تسجيل تبويب الإبداع");
	}
}
