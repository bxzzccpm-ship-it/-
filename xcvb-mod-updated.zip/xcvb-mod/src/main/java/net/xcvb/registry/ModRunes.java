package net.xcvb.registry;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.xcvb.Xcvb;
import net.xcvb.rune.RuneItem;
import net.xcvb.rune.RuneType;

public class ModRunes {

	public static final Item RUNE_OF_THE_VOID = register("rune_of_the_void", RuneType.VOID);
	public static final Item RUNE_OF_STORMS = register("rune_of_storms", RuneType.STORM);
	public static final Item RUNE_OF_FROST = register("rune_of_frost", RuneType.FROST);
	public static final Item RUNE_OF_FLAMES = register("rune_of_flames", RuneType.FLAME);

	private static Item register(String name, RuneType type) {
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name),
				new RuneItem(type, new FabricItemSettings().rarity(Rarity.EPIC)));
	}

	public static void registerRunes() {
		Xcvb.LOGGER.info("XCVB: تسجيل الرونات");
	}
}
