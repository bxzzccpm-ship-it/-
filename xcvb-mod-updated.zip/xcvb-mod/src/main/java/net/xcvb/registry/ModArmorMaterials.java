package net.xcvb.registry;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

import java.util.List;
import java.util.Map;

/**
 * مادة درع مخصصة اسمها "arcanite" بدل ما نعيد استخدام NETHERITE.
 * هذا يخلي اللعبة تدور على تكستشر الدرع بمسار:
 *   assets/xcvb/textures/models/armor/arcanite_layer_1.png
 *   assets/xcvb/textures/models/armor/arcanite_layer_2.png
 * بدل تكستشر النذرايت الرمادي.
 *
 * ملاحظة: هذا الجزء أكثر حساسية لاختلاف نسخة الـ Yarn Mappings بالضبط. إذا IntelliJ
 * سوى تحته خط أحمر، الأغلب يكون بترتيب أو نوع أحد المعاملات بمنشئ ArmorMaterial -
 * انسخ لي رسالة الخطأ وأصلحها فورًا.
 */
public class ModArmorMaterials {

	private static final TagKey<net.minecraft.item.Item> REPAIRS_ARCANITE_ARMOR =
			TagKey.of(RegistryKeys.ITEM, Identifier.of(Xcvb.MOD_ID, "repairs_arcanite_armor"));

	public static final RegistryEntry<ArmorMaterial> ARCANITE = RegistryEntry.of(new ArmorMaterial(
			37, // durability multiplier (نفس النذرايت)
			Map.of(
					ArmorItem.Type.BOOTS, 3,
					ArmorItem.Type.LEGGINGS, 6,
					ArmorItem.Type.CHESTPLATE, 8,
					ArmorItem.Type.HELMET, 3,
					ArmorItem.Type.BODY, 11
			),
			15, // enchantability
			RegistryEntry.of(SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE),
			3.0F, // toughness
			0.1F, // knockback resistance
			REPAIRS_ARCANITE_ARMOR,
			List.of(new ArmorMaterial.Layer(Identifier.of(Xcvb.MOD_ID, "arcanite")))
	));
}
