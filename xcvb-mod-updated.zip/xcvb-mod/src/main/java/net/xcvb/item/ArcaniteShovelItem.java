package net.xcvb.item;

import net.minecraft.item.ShovelItem;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;

public class ArcaniteShovelItem extends ShovelItem {
	public ArcaniteShovelItem(ToolMaterial material, float attackDamage, float attackSpeed, Item.Settings settings) {
		super(material, attackDamage, attackSpeed, settings);
	}
}
