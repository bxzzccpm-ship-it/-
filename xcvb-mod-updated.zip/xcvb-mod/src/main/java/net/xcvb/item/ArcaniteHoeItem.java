package net.xcvb.item;

import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;

public class ArcaniteHoeItem extends HoeItem {
	public ArcaniteHoeItem(ToolMaterial material, float attackDamage, float attackSpeed, Item.Settings settings) {
		super(material, attackDamage, attackSpeed, settings);
	}
}
