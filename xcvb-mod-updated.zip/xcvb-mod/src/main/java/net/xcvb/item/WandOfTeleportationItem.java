package net.xcvb.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

/**
 * Wand of Teleportation: تنقلك 12 بلوك بالاتجاه اللي تنظر له (أو أقل إذا فيه عائق).
 * كولداون ثانيتين.
 */
public class WandOfTeleportationItem extends Item {

	private static final double MAX_DISTANCE = 12.0;
	private static final int COOLDOWN_TICKS = 40; // 2 seconds

	public WandOfTeleportationItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}

		HitResult hit = user.raycast(MAX_DISTANCE, 1.0F, false);
		double distance = hit.getPos().distanceTo(user.getPos());
		double safeDistance = Math.max(0, distance - 1.0);

		net.minecraft.util.math.Vec3d look = user.getRotationVec(1.0F);
		net.minecraft.util.math.Vec3d destination = user.getPos().add(look.multiply(safeDistance));

		if (!world.isClient && world instanceof ServerWorld serverWorld) {
			serverWorld.spawnParticles(ParticleTypes.REVERSE_PORTAL, user.getX(), user.getY() + 1, user.getZ(), 30, 0.3, 0.5, 0.3, 0.05);
			user.teleport(destination.x, destination.y, destination.z, false);
			serverWorld.spawnParticles(ParticleTypes.REVERSE_PORTAL, user.getX(), user.getY() + 1, user.getZ(), 30, 0.3, 0.5, 0.3, 0.05);
			world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
			user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
		}

		return TypedActionResult.success(stack, world.isClient());
	}
}
