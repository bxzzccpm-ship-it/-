package net.xcvb.item;

import net.minecraft.item.Item;

/**
 * Amulet of Vitality: تعويذة سلبية (Passive).
 * ما تحتاج تستخدمها (Right Click) - يكفي تكون بأي مكان بجيبك (Inventory)
 * وراح تشتغل تلقائياً عن طريق AmuletTickHandler اللي يفحص جيب اللاعب كل شوي
 * ويعطيه Regeneration خفيف باستمرار.
 */
public class AmuletOfVitalityItem extends Item {
	public AmuletOfVitalityItem(Settings settings) {
		super(settings);
	}
}
