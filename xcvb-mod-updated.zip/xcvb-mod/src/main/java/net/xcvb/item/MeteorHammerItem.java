package net.xcvb.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/**
 * Meteor Hammer: مطرقة النيازك.
 * اضغط يمين -> ضربة أرضية (AOE) بمدى 5 بلوك حولك: ضرر + دفع (Knockback) لكل الأعداء بالمنطقة.
 * كولداون 8 ثواني - سلاح قوي بس بطيء.
 */
public class MeteorHammerItem extends Item {

	private static final double RADIUS = 5.0;
	private static final float DAMAGE = 8.0F;
	private static final int COOLDOWN_TICKS = 160;

	public MeteorHammerItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}

		Box area = user.getBoundingBox().expand(RADIUS);

		for (Entity entity : world.getOtherEntities(user, area)) {
			if (!(entity instanceof LivingEntity living)) continue;
			double dx = living.getX() - user.getX();
			double dz = living.getZ() - user.getZ();

			living.damage((ServerWorld) world, world.getDamageSources().playerAttack(user), DAMAGE);
			living.takeKnockback(1.2, -dx, -dz);
		}

		if (world instanceof ServerWorld serverWorld) {
			serverWorld.spawnParticles(ParticleTypes.EXPLOSION, user.getX(), user.getY() + 0.2, user.getZ(), 3, 0.5, 0.2, 0.5, 0.0);
			serverWorld.spawnParticles(ParticleTypes.LAVA, user.getX(), user.getY() + 0.2, user.getZ(), 20, RADIUS / 2, 0.2, RADIUS / 2, 0.0);
		}
		world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.8F);
		user.getItemCooldownManager().set(this, COOLDOWN_TICKS);

		return TypedActionResult.success(stack, world.isClient());
	}
}
