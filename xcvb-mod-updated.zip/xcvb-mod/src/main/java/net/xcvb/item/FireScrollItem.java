package net.xcvb.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Fire Scroll: لفافة نار - عنصر استهلاكي (تُستخدم مرة وحدة وتنتهي).
 * اضغط يمين وأنت تنظر لعدو بمدى 10 بلوك -> يشتعل بالنار لمدة 8 ثواني.
 */
public class FireScrollItem extends Item {

	private static final double RANGE = 10.0;

	public FireScrollItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		LivingEntity target = findTarget(world, user, RANGE);

		if (target != null) {
			target.setFireTicks(160);

			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.FLAME, target.getX(), target.getY() + 1, target.getZ(), 25, 0.4, 0.6, 0.4, 0.02);
			}
			world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 1.0F, 1.0F);

			if (!user.getAbilities().creativeMode) {
				stack.decrement(1);
			}
			return TypedActionResult.success(stack, world.isClient());
		}

		return TypedActionResult.pass(stack);
	}

	private LivingEntity findTarget(World world, PlayerEntity user, double range) {
		Vec3d start = user.getCameraPosVec(1.0F);
		Vec3d look = user.getRotationVec(1.0F);
		Vec3d end = start.add(look.multiply(range));

		LivingEntity closest = null;
		double closestDist = range;

		for (net.minecraft.entity.Entity entity : world.getOtherEntities(user, user.getBoundingBox().stretch(look.multiply(range)).expand(1.0))) {
			if (!(entity instanceof LivingEntity living)) continue;
			double dist = entity.getPos().distanceTo(start);
			if (dist < closestDist && entity.getBoundingBox().expand(0.3).raycast(start, end).isPresent()) {
				closest = living;
				closestDist = dist;
			}
		}
		return closest;
	}
}
