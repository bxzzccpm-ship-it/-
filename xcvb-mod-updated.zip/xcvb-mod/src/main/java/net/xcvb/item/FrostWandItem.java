package net.xcvb.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Frost Wand: عصا التجميد.
 * اضغط يمين وأنت تنظر لعدو بمدى 10 بلوك -> يصير عليه بطء شديد + إعياء تعدين (Freeze effect) لمدة 6 ثواني.
 * كولداون 4 ثواني.
 */
public class FrostWandItem extends Item {

	private static final double RANGE = 10.0;
	private static final int COOLDOWN_TICKS = 80;

	public FrostWandItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}

		LivingEntity target = findTarget(world, user, RANGE);

		if (target != null) {
			target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 4));
			target.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 120, 2));

			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 1, target.getZ(), 30, 0.4, 0.6, 0.4, 0.02);
			}
			world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 0.8F, 0.6F);
			user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
			return TypedActionResult.success(stack, world.isClient());
		}

		return TypedActionResult.pass(stack);
	}

	private LivingEntity findTarget(World world, PlayerEntity user, double range) {
		Vec3d start = user.getCameraPosVec(1.0F);
		Vec3d look = user.getRotationVec(1.0F);
		Vec3d end = start.add(look.multiply(range));

		LivingEntity closest = null;
		double closestDist = range;

		for (net.minecraft.entity.Entity entity : world.getOtherEntities(user, user.getBoundingBox().stretch(look.multiply(range)).expand(1.0))) {
			if (!(entity instanceof LivingEntity living)) continue;
			double dist = entity.getPos().distanceTo(start);
			if (dist < closestDist && entity.getBoundingBox().expand(0.3).raycast(start, end).isPresent()) {
				closest = living;
				closestDist = dist;
			}
		}
		return closest;
	}
}
