package net.xcvb.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext;

/**
 * Staff of Storms: عصا سحرية.
 * الضغط يمين -> يبحث عن أقرب هدف بمدى 20 بلوك أمامك ويرمي عليه صاعقة.
 * كولداون 5 ثواني.
 */
public class StaffOfStormsItem extends Item {

	private static final double RANGE = 20.0;
	private static final int COOLDOWN_TICKS = 100; // 5 seconds

	public StaffOfStormsItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<net.minecraft.item.ItemStack> use(World world, PlayerEntity user, Hand hand) {
		net.minecraft.item.ItemStack stack = user.getStackInHand(hand);

		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}

		LivingEntity target = findTarget(world, user, RANGE);

		if (!world.isClient && world instanceof ServerWorld serverWorld) {
			BlockPos strikePos;
			if (target != null) {
				strikePos = target.getBlockPos();
			} else {
				// Strike where the player is looking at the ground
				HitResult blockHit = user.raycast(RANGE, 1.0F, false);
				strikePos = BlockPos.ofFloored(blockHit.getPos());
			}

			LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(serverWorld);
			if (lightning != null) {
				lightning.refreshPositionAfterTeleport(Vec3d.ofBottomCenter(strikePos));
				lightning.setChanneler(user instanceof net.minecraft.server.network.ServerPlayerEntity sp ? sp : null);
				serverWorld.spawnEntity(lightning);
			}

			world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 1.0F, 1.0F);
			user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
		}

		return TypedActionResult.success(stack, world.isClient());
	}

	private LivingEntity findTarget(World world, PlayerEntity user, double range) {
		Vec3d start = user.getCameraPosVec(1.0F);
		Vec3d look = user.getRotationVec(1.0F);
		Vec3d end = start.add(look.multiply(range));

		LivingEntity closest = null;
		double closestDist = range;

		for (net.minecraft.entity.Entity entity : world.getOtherEntities(user, user.getBoundingBox().stretch(look.multiply(range)).expand(1.0))) {
			if (!(entity instanceof LivingEntity living)) continue;
			double dist = entity.getPos().distanceTo(start);
			if (dist < closestDist && entity.getBoundingBox().expand(0.3).raycast(start, end).isPresent()) {
				closest = living;
				closestDist = dist;
			}
		}
		return closest;
	}
}
