package net.xcvb.item;

import net.minecraft.item.Item;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;

public class ArcanitePickaxeItem extends PickaxeItem {
	public ArcanitePickaxeItem(ToolMaterial material, int attackDamage, float attackSpeed, Item.Settings settings) {
		super(material, attackDamage, attackSpeed, settings);
	}
}
