package net.xcvb.item;

import net.minecraft.entity.Entity;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Void Blade: سيف سحري.
 * الضغط يمين (Right Click) وأنت تنظر لعدو ضمن مدى 8 بلوك -> تنتقل (Blink) لجنبه فوراً.
 * يستخدم كولداون 3 ثواني حتى ما يصير مبالغ فيه بالقوة.
 */
public class VoidBladeItem extends SwordItem {

	private static final double BLINK_RANGE = 8.0;
	private static final int COOLDOWN_TICKS = 60; // 3 seconds

	public VoidBladeItem(ToolMaterial material, int attackDamage, float attackSpeed, Item.Settings settings) {
		super(material, attackDamage, attackSpeed, settings);
	}

	@Override
	public ActionResult use(World world, net.minecraft.entity.player.PlayerEntity user, Hand hand) {
		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return ActionResult.PASS;
		}

		HitResult hit = raytraceForEntity(world, user, BLINK_RANGE);

		if (hit instanceof EntityHitResult entityHit) {
			Entity target = entityHit.getEntity();
			Vec3d blinkPos = target.getPos().add(target.getRotationVector().multiply(-1.2));

			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.PORTAL, user.getX(), user.getY() + 1, user.getZ(), 40, 0.5, 0.5, 0.5, 0.1);
				user.teleport(blinkPos.x, blinkPos.y, blinkPos.z, false);
				serverWorld.spawnParticles(ParticleTypes.PORTAL, user.getX(), user.getY() + 1, user.getZ(), 40, 0.5, 0.5, 0.5, 0.1);
				user.attack(target);
			}

			world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
			user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
			return ActionResult.SUCCESS;
		}

		return ActionResult.PASS;
	}

	private HitResult raytraceForEntity(World world, net.minecraft.entity.player.PlayerEntity user, double range) {
		Vec3d start = user.getCameraPosVec(1.0F);
		Vec3d look = user.getRotationVec(1.0F);
		Vec3d end = start.add(look.multiply(range));

		Entity closest = null;
		double closestDist = range;

		for (Entity entity : world.getOtherEntities(user, user.getBoundingBox().stretch(look.multiply(range)).expand(1.0))) {
			double dist = entity.getPos().distanceTo(start);
			if (dist < closestDist && entity.getBoundingBox().expand(0.3).raycast(start, end).isPresent()) {
				closest = entity;
				closestDist = dist;
			}
		}

		if (closest != null) {
			return new EntityHitResult(closest);
		}
		return null;
	}
}
