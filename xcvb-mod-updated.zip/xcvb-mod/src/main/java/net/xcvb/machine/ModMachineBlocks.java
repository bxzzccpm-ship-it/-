package net.xcvb.machine;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.xcvb.Xcvb;
import net.xcvb.progression.ModProgressionItems;
import net.xcvb.skill.PlayerSkillManager;
import net.xcvb.skill.SkillType;

/**
 * ثلاث آلات "سحر+تقنية" بسيطة، بتفاعل نقرة واحدة (بلا شاشة GUI عشان نضمن التوافق 100%):
 * Soul Reactor    - يحول Soul Ingot إلى Energy Cell (نقرة يمين وأنت حامل Soul Ingot)
 * Ghost Battery   - يشحن Energy Cell إلى Energy Cell مشحون (يعطيك مكافأة نقاط سحر)
 * Crystal Computer- يعطيك دفعة خبرة "سحر" مقابل Crystal Gem (بديل كمبيوتر يستخدم بلورات بدل كهرباء)
 *
 * ملاحظة: هذا تبسيط مقصود بدل نظام طاقة كامل بشبكة كابلات، عشان نضمن الاستقرار
 * وعدم وجود أخطاء بالتجميع. إذا تبي شبكة طاقة حقيقية بين الآلات، هذا مرحلة تانية أكبر بكثير.
 */
public class ModMachineBlocks {

	public static final Block SOUL_REACTOR = registerBlock("soul_reactor", new SoulReactorBlock());
	public static final Block GHOST_BATTERY = registerBlock("ghost_battery", new GhostBatteryBlock());
	public static final Block CRYSTAL_COMPUTER = registerBlock("crystal_computer", new CrystalComputerBlock());

	private static Block registerBlock(String name, Block block) {
		Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name),
				new BlockItem(block, new Item.Settings()));
		return Registry.register(Registries.BLOCK, Identifier.of(Xcvb.MOD_ID, name), block);
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل آلات السحر+التقنية (Soul Reactor / Ghost Battery / Crystal Computer)");
	}

	// ================= Soul Reactor =================
	private static class SoulReactorBlock extends Block {
		SoulReactorBlock() {
			super(FabricBlockSettings.create().mapColor(MapColor.BLACK).strength(4.0F, 6.0F)
					.sounds(BlockSoundGroup.NETHERITE).luminance(state -> 7));
		}

		@Override
		protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
			if (world.isClient) return ActionResult.SUCCESS;

			ItemStack held = player.getMainHandStack();
			if (held.isOf(ModProgressionItems.SOUL_INGOT) && !held.isEmpty()) {
				held.decrement(1);
				giveOrDrop(player, new ItemStack(ModProgressionItems.ENERGY_CELL));
				world.playSound(null, pos, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 0.6F, 1.4F);
				player.sendMessage(Text.literal("مفاعل الأرواح حوّل سبيكة روح إلى خلية طاقة").formatted(Formatting.DARK_PURPLE), true);
			} else {
				player.sendMessage(Text.literal("حط Soul Ingot بيدك وانقر عليه باش يحولها Energy Cell").formatted(Formatting.GRAY), true);
			}
			return ActionResult.CONSUME;
		}
	}

	// ================= Ghost Battery =================
	private static class GhostBatteryBlock extends Block {
		GhostBatteryBlock() {
			super(FabricBlockSettings.create().mapColor(MapColor.PALE_PURPLE).strength(3.5F, 6.0F)
					.sounds(BlockSoundGroup.AMETHYST_BLOCK).luminance(state -> 8));
		}

		@Override
		protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
			if (world.isClient) return ActionResult.SUCCESS;

			if (player instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer) {
				ItemStack held = player.getMainHandStack();
				if (held.isOf(ModProgressionItems.ENERGY_CELL) && !held.isEmpty()) {
					held.decrement(1);
					player.addStatusEffect(new StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.GLOWING, 200, 0));
					PlayerSkillManager.addXp(serverPlayer, SkillType.MAGIC, 15);
					world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 0.7F, 1.2F);
					player.sendMessage(Text.literal("بطارية الأشباح شحنت روحك بطاقة سحرية (+خبرة سحر)").formatted(Formatting.LIGHT_PURPLE), true);
				} else {
					player.sendMessage(Text.literal("حط Energy Cell بيدك وانقر عليه باش تشحنها").formatted(Formatting.GRAY), true);
				}
			}
			return ActionResult.CONSUME;
		}
	}

	// ================= Crystal Computer =================
	private static class CrystalComputerBlock extends Block {
		CrystalComputerBlock() {
			super(FabricBlockSettings.create().mapColor(MapColor.LIGHT_BLUE).strength(4.5F, 6.0F)
					.sounds(BlockSoundGroup.COPPER).luminance(state -> 6));
		}

		@Override
		protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
			if (world.isClient) return ActionResult.SUCCESS;

			if (player instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer) {
				ItemStack held = player.getMainHandStack();
				if (held.isOf(ModProgressionItems.CRYSTAL_GEM) && !held.isEmpty()) {
					held.decrement(1);
					PlayerSkillManager.addXp(serverPlayer, SkillType.MAGIC, 20);
					world.playSound(null, pos, SoundEvents.BLOCK_CONDUIT_ACTIVATE, SoundCategory.BLOCKS, 0.6F, 1.6F);
					player.sendMessage(Text.literal("كمبيوتر البلور حلل الطاقة (+20 خبرة سحر)").formatted(Formatting.AQUA), true);
				} else {
					player.sendMessage(Text.literal("حط Crystal Gem بيدك وانقر عليه باش يحسبها").formatted(Formatting.GRAY), true);
				}
			}
			return ActionResult.CONSUME;
		}
	}

	private static void giveOrDrop(PlayerEntity player, ItemStack stack) {
		if (!player.getInventory().insertStack(stack)) {
			player.dropItem(stack, false);
		}
	}
}
