package net.xcvb.progression;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.xcvb.Xcvb;

/**
 * سلسلة التقدم: Iron -> Crystal -> Soul -> Ancient -> Void
 * كل مستوى أدواته أقوى من الثاني. اعتمدنا على إحصائيات DIAMOND و NETHERITE
 * الجاهزة بالماين كرافت كأساس (نفس أسلوب Arcanite المستخدم بالمود أصلاً)
 * بدل تعريف ToolMaterial مخصص بالكامل، هذا يخلي التوافق مضمون 100%.
 */
public class ModProgressionItems {

	// ===== المواد الخام (تسقط من الخامات) =====
	public static final Item RAW_SOUL = registerItem("raw_soul", new Item(new FabricItemSettings()));
	public static final Item CRYSTAL_GEM = registerItem("crystal_gem", new Item(new FabricItemSettings()));
	public static final Item BLOOD_SHARD = registerItem("blood_shard", new Item(new FabricItemSettings()));
	public static final Item ENERGY_CELL = registerItem("energy_cell", new Item(new FabricItemSettings()));

	// ===== السبائك المصهورة =====
	public static final Item SOUL_INGOT = registerItem("soul_ingot",
			new Item(new FabricItemSettings().rarity(Rarity.UNCOMMON)));

	// ===== سبائك الدمج (تصنع، ما تصهر) =====
	public static final Item ANCIENT_INGOT = registerItem("ancient_ingot",
			new Item(new FabricItemSettings().rarity(Rarity.RARE)));
	public static final Item VOID_INGOT = registerItem("void_ingot",
			new Item(new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));

	// ===== أدوات Crystal (أساس Diamond) =====
	public static final Item CRYSTAL_PICKAXE = registerItem("crystal_pickaxe",
			new PickaxeItem(ToolMaterials.DIAMOND, 1, -2.6F, new FabricItemSettings()));
	public static final Item CRYSTAL_AXE = registerItem("crystal_axe",
			new AxeItem(ToolMaterials.DIAMOND, 5.5F, -3.0F, new FabricItemSettings()));
	public static final Item CRYSTAL_SHOVEL = registerItem("crystal_shovel",
			new ShovelItem(ToolMaterials.DIAMOND, 1.5F, -3.0F, new FabricItemSettings()));
	public static final Item CRYSTAL_HOE = registerItem("crystal_hoe",
			new HoeItem(ToolMaterials.DIAMOND, -2.0F, -1.0F, new FabricItemSettings()));
	public static final Item CRYSTAL_SWORD = registerItem("crystal_sword",
			new SwordItem(ToolMaterials.DIAMOND, 3, -2.4F, new FabricItemSettings()));

	// ===== أدوات Soul (أقوى من Diamond، أضعف من Netherite) =====
	public static final Item SOUL_PICKAXE = registerItem("soul_pickaxe",
			new PickaxeItem(ToolMaterials.NETHERITE, 1, -2.7F, new FabricItemSettings()));
	public static final Item SOUL_AXE = registerItem("soul_axe",
			new AxeItem(ToolMaterials.NETHERITE, 6.0F, -3.0F, new FabricItemSettings()));
	public static final Item SOUL_SHOVEL = registerItem("soul_shovel",
			new ShovelItem(ToolMaterials.NETHERITE, 1.5F, -3.0F, new FabricItemSettings()));
	public static final Item SOUL_HOE = registerItem("soul_hoe",
			new HoeItem(ToolMaterials.NETHERITE, -1.5F, -0.5F, new FabricItemSettings()));
	public static final Item SOUL_SWORD = registerItem("soul_sword",
			new SwordItem(ToolMaterials.NETHERITE, 3, -2.3F, new FabricItemSettings()));

	// ===== أدوات Ancient (أساس Netherite، إحصائيات أعلى) =====
	public static final Item ANCIENT_PICKAXE = registerItem("ancient_pickaxe",
			new PickaxeItem(ToolMaterials.NETHERITE, 2, -2.6F, new FabricItemSettings().rarity(Rarity.RARE)));
	public static final Item ANCIENT_AXE = registerItem("ancient_axe",
			new AxeItem(ToolMaterials.NETHERITE, 7.0F, -2.9F, new FabricItemSettings().rarity(Rarity.RARE)));
	public static final Item ANCIENT_SHOVEL = registerItem("ancient_shovel",
			new ShovelItem(ToolMaterials.NETHERITE, 2.5F, -2.9F, new FabricItemSettings().rarity(Rarity.RARE)));
	public static final Item ANCIENT_HOE = registerItem("ancient_hoe",
			new HoeItem(ToolMaterials.NETHERITE, -1.0F, -0.2F, new FabricItemSettings().rarity(Rarity.RARE)));
	public static final Item ANCIENT_SWORD = registerItem("ancient_sword",
			new SwordItem(ToolMaterials.NETHERITE, 4, -2.2F, new FabricItemSettings().rarity(Rarity.RARE)));

	// ===== أدوات Void (القمة) =====
	public static final Item VOID_PICKAXE = registerItem("void_pickaxe",
			new PickaxeItem(ToolMaterials.NETHERITE, 3, -2.4F, new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));
	public static final Item VOID_AXE = registerItem("void_axe",
			new AxeItem(ToolMaterials.NETHERITE, 8.0F, -2.7F, new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));
	public static final Item VOID_SHOVEL = registerItem("void_shovel",
			new ShovelItem(ToolMaterials.NETHERITE, 3.5F, -2.7F, new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));
	public static final Item VOID_HOE = registerItem("void_hoe",
			new HoeItem(ToolMaterials.NETHERITE, -0.5F, 0.0F, new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));
	public static final Item VOID_SWORD = registerItem("void_sword",
			new SwordItem(ToolMaterials.NETHERITE, 5, -2.0F, new FabricItemSettings().rarity(Rarity.EPIC).fireproof()));

	private static Item registerItem(String name, Item item) {
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name), item);
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل عناصر التقدم (سبائك + أدوات)");
	}
}
