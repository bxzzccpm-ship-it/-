package net.xcvb.progression;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.xcvb.Xcvb;

import java.util.List;
import java.util.Map;

/**
 * أربع مجموعات دروع، كل وحدة عندها قدرة خاصة (مطبقة عبر ProgressionArmorAbilityHandler):
 * Soul Armor    - رؤية ليلية + مقاومة (رمز "رؤية الأرواح")
 * Electric Armor- يصعق من يضربك + مناعة من الصواعق
 * Ice Armor     - مناعة نار كاملة + تقليل الانزلاق على الجليد
 * Void Armor    - تقليل ضرر السقوط + تيليبورت قصير عشوائي عند إصابة قاتلة
 */
public class ModProgressionArmor {

	private static final TagKey<Item> REPAIRS_SOUL =
			TagKey.of(RegistryKeys.ITEM, Identifier.of(Xcvb.MOD_ID, "repairs_soul_armor"));
	private static final TagKey<Item> REPAIRS_ELECTRIC =
			TagKey.of(RegistryKeys.ITEM, Identifier.of(Xcvb.MOD_ID, "repairs_electric_armor"));
	private static final TagKey<Item> REPAIRS_ICE =
			TagKey.of(RegistryKeys.ITEM, Identifier.of(Xcvb.MOD_ID, "repairs_ice_armor"));
	private static final TagKey<Item> REPAIRS_VOID =
			TagKey.of(RegistryKeys.ITEM, Identifier.of(Xcvb.MOD_ID, "repairs_void_armor"));

	public static final RegistryEntry<ArmorMaterial> SOUL = RegistryEntry.of(new ArmorMaterial(
			33, Map.of(ArmorItem.Type.BOOTS, 3, ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.CHESTPLATE, 8,
			ArmorItem.Type.HELMET, 3, ArmorItem.Type.BODY, 11),
			14, RegistryEntry.of(SoundEvents.ITEM_ARMOR_EQUIP_GOLD), 2.0F, 0.0F,
			REPAIRS_SOUL, List.of(new ArmorMaterial.Layer(Identifier.of(Xcvb.MOD_ID, "soul")))));

	public static final RegistryEntry<ArmorMaterial> ELECTRIC = RegistryEntry.of(new ArmorMaterial(
			35, Map.of(ArmorItem.Type.BOOTS, 3, ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.CHESTPLATE, 8,
			ArmorItem.Type.HELMET, 3, ArmorItem.Type.BODY, 11),
			18, RegistryEntry.of(SoundEvents.ITEM_ARMOR_EQUIP_IRON), 2.5F, 0.05F,
			REPAIRS_ELECTRIC, List.of(new ArmorMaterial.Layer(Identifier.of(Xcvb.MOD_ID, "electric")))));

	public static final RegistryEntry<ArmorMaterial> ICE = RegistryEntry.of(new ArmorMaterial(
			35, Map.of(ArmorItem.Type.BOOTS, 3, ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.CHESTPLATE, 8,
			ArmorItem.Type.HELMET, 3, ArmorItem.Type.BODY, 11),
			16, RegistryEntry.of(SoundEvents.ITEM_ARMOR_EQUIP_CHAIN), 2.5F, 0.05F,
			REPAIRS_ICE, List.of(new ArmorMaterial.Layer(Identifier.of(Xcvb.MOD_ID, "ice")))));

	public static final RegistryEntry<ArmorMaterial> VOID = RegistryEntry.of(new ArmorMaterial(
			40, Map.of(ArmorItem.Type.BOOTS, 3, ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.CHESTPLATE, 8,
			ArmorItem.Type.HELMET, 3, ArmorItem.Type.BODY, 11),
			20, RegistryEntry.of(SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE), 3.5F, 0.15F,
			REPAIRS_VOID, List.of(new ArmorMaterial.Layer(Identifier.of(Xcvb.MOD_ID, "void")))));

	// ===== دروع الأرواح =====
	public static final Item SOUL_HELMET = registerArmor("soul_helmet", SOUL, ArmorItem.Type.HELMET, Rarity.UNCOMMON);
	public static final Item SOUL_CHESTPLATE = registerArmor("soul_chestplate", SOUL, ArmorItem.Type.CHESTPLATE, Rarity.UNCOMMON);
	public static final Item SOUL_LEGGINGS = registerArmor("soul_leggings", SOUL, ArmorItem.Type.LEGGINGS, Rarity.UNCOMMON);
	public static final Item SOUL_BOOTS = registerArmor("soul_boots", SOUL, ArmorItem.Type.BOOTS, Rarity.UNCOMMON);

	// ===== الدرع الكهربائي =====
	public static final Item ELECTRIC_HELMET = registerArmor("electric_helmet", ELECTRIC, ArmorItem.Type.HELMET, Rarity.RARE);
	public static final Item ELECTRIC_CHESTPLATE = registerArmor("electric_chestplate", ELECTRIC, ArmorItem.Type.CHESTPLATE, Rarity.RARE);
	public static final Item ELECTRIC_LEGGINGS = registerArmor("electric_leggings", ELECTRIC, ArmorItem.Type.LEGGINGS, Rarity.RARE);
	public static final Item ELECTRIC_BOOTS = registerArmor("electric_boots", ELECTRIC, ArmorItem.Type.BOOTS, Rarity.RARE);

	// ===== الدرع الجليدي =====
	public static final Item ICE_HELMET = registerArmor("ice_helmet", ICE, ArmorItem.Type.HELMET, Rarity.RARE);
	public static final Item ICE_CHESTPLATE = registerArmor("ice_chestplate", ICE, ArmorItem.Type.CHESTPLATE, Rarity.RARE);
	public static final Item ICE_LEGGINGS = registerArmor("ice_leggings", ICE, ArmorItem.Type.LEGGINGS, Rarity.RARE);
	public static final Item ICE_BOOTS = registerArmor("ice_boots", ICE, ArmorItem.Type.BOOTS, Rarity.RARE);

	// ===== درع الفراغ =====
	public static final Item VOID_HELMET = registerArmor("void_helmet", VOID, ArmorItem.Type.HELMET, Rarity.EPIC);
	public static final Item VOID_CHESTPLATE = registerArmor("void_chestplate", VOID, ArmorItem.Type.CHESTPLATE, Rarity.EPIC);
	public static final Item VOID_LEGGINGS = registerArmor("void_leggings", VOID, ArmorItem.Type.LEGGINGS, Rarity.EPIC);
	public static final Item VOID_BOOTS = registerArmor("void_boots", VOID, ArmorItem.Type.BOOTS, Rarity.EPIC);

	private static Item registerArmor(String name, RegistryEntry<ArmorMaterial> material, ArmorItem.Type type, Rarity rarity) {
		Item item = new ArmorItem(material, type, new FabricItemSettings().rarity(rarity));
		return Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name), item);
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل دروع التقدم (أرواح/كهربائي/جليدي/فراغ)");
	}
}
