package net.xcvb.progression;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * قدرات الدروع الأربعة الجديدة.
 * الفحص الدوري (Tick) لقدرات ثابتة، وحدث AFTER_DAMAGE للقدرات اللي تصير عند الإصابة.
 */
public class ProgressionArmorAbilityHandler {

	private static final Random RANDOM = new Random();
	private static final int CHECK_INTERVAL = 40; // كل ثانيتين

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(ProgressionArmorAbilityHandler::onTick);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(ProgressionArmorAbilityHandler::onAfterDamage);
	}

	private static void onTick(MinecraftServer server) {
		if (server.getTicks() % CHECK_INTERVAL != 0) return;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			if (isFullSet(player, ModProgressionArmor.SOUL_HELMET, ModProgressionArmor.SOUL_CHESTPLATE,
					ModProgressionArmor.SOUL_LEGGINGS, ModProgressionArmor.SOUL_BOOTS)) {
				// درع الأرواح: رؤية ليلية (يشوف بالضلمة كأنه يشوف الأرواح) + مقاومة خفيفة
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 260, 0, true, false));
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 0, true, false));
			}

			if (isFullSet(player, ModProgressionArmor.ICE_HELMET, ModProgressionArmor.ICE_CHESTPLATE,
					ModProgressionArmor.ICE_LEGGINGS, ModProgressionArmor.ICE_BOOTS)) {
				// الدرع الجليدي: مناعة كاملة من النار + عدم الانزلاق (مقاومة دفع خفيفة كبديل)
				player.setFireTicks(0);
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 60, 0, true, false));
			}

			if (isFullSet(player, ModProgressionArmor.ELECTRIC_HELMET, ModProgressionArmor.ELECTRIC_CHESTPLATE,
					ModProgressionArmor.ELECTRIC_LEGGINGS, ModProgressionArmor.ELECTRIC_BOOTS)) {
				// الدرع الكهربائي: مناعة من الصواعق
				if (player.isOnFire() && player.getWorld().isThundering()) {
					player.extinguish();
				}
			}

			if (isFullSet(player, ModProgressionArmor.VOID_HELMET, ModProgressionArmor.VOID_CHESTPLATE,
					ModProgressionArmor.VOID_LEGGINGS, ModProgressionArmor.VOID_BOOTS)) {
				// درع الفراغ: يقلل ضرر السقوط بشكل دائم
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 60, 0, true, false));
			}
		}
	}

	private static void onAfterDamage(LivingEntity entity, DamageSource source, float baseDamageTaken,
			float damageTaken, boolean blocked) {
		if (!(entity instanceof ServerPlayerEntity player)) return;
		if (damageTaken <= 0) return;

		// الدرع الكهربائي: يصعق من ضربك (Attacker) بضرر إضافي + إبطاء
		if (isFullSet(player, ModProgressionArmor.ELECTRIC_HELMET, ModProgressionArmor.ELECTRIC_CHESTPLATE,
				ModProgressionArmor.ELECTRIC_LEGGINGS, ModProgressionArmor.ELECTRIC_BOOTS)) {
			if (source.getAttacker() instanceof LivingEntity attacker) {
				attacker.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
				attacker.damage((net.minecraft.server.world.ServerWorld) player.getWorld(),
						player.getDamageSources().lightningBolt(), 2.0F);
			}
		}

		// درع الفراغ: عند إصابة قوية (>40% من صحته)، فرصة تيليبورت قصير للهروب
		if (isFullSet(player, ModProgressionArmor.VOID_HELMET, ModProgressionArmor.VOID_CHESTPLATE,
				ModProgressionArmor.VOID_LEGGINGS, ModProgressionArmor.VOID_BOOTS)) {
			if (damageTaken > player.getMaxHealth() * 0.4F && RANDOM.nextFloat() < 0.5F) {
				Vec3d pos = player.getPos();
				double dx = (RANDOM.nextDouble() - 0.5) * 8.0;
				double dz = (RANDOM.nextDouble() - 0.5) * 8.0;
				player.teleport(pos.x + dx, pos.y + 1, pos.z + dz, false);
			}
		}
	}

	private static boolean isFullSet(ServerPlayerEntity player, net.minecraft.item.Item head,
			net.minecraft.item.Item chest, net.minecraft.item.Item legs, net.minecraft.item.Item feet) {
		ItemStack h = player.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack c = player.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack l = player.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack b = player.getEquippedStack(EquipmentSlot.FEET);
		return h.isOf(head) && c.isOf(chest) && l.isOf(legs) && b.isOf(feet);
	}
}
