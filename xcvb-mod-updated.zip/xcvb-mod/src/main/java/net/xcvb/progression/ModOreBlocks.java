package net.xcvb.progression;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

/**
 * أربع خامات جديدة، كل وحدة بغرض خاص:
 * Soul Ore - أرواح (قوة السحر)
 * Crystal Ore - بلورات (طاقة سحرية)
 * Blood Ore - دم (سيوف / جرعات)
 * Energy Ore - طاقة (يشغل الآلات)
 *
 * كل بلوك عند كسره كيسقط نفسه (مثل باقي خامات الماينكرافت)، وبعدين تصهره بالفرن
 * باش تحصل على المادة الخام (Ingot/Gem) المستخدمة بالوصفات.
 */
public class ModOreBlocks {

	public static final Block SOUL_ORE = registerOre("soul_ore", MapColor.DEEPSLATE_GRAY, 4.0F, 5.0F);
	public static final Block CRYSTAL_ORE = registerOre("crystal_ore", MapColor.LIGHT_BLUE, 3.5F, 5.0F);
	public static final Block BLOOD_ORE = registerOre("blood_ore", MapColor.RED, 4.5F, 5.5F);
	public static final Block ENERGY_ORE = registerOre("energy_ore", MapColor.YELLOW, 3.5F, 5.0F);

	private static Block registerOre(String name, MapColor color, float hardness, float resistance) {
		Block block = new Block(FabricBlockSettings.create()
				.mapColor(color)
				.strength(hardness, resistance)
				.requiresTool()
				.sounds(BlockSoundGroup.DEEPSLATE));
		Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name),
				new BlockItem(block, new Item.Settings()));
		return Registry.register(Registries.BLOCK, Identifier.of(Xcvb.MOD_ID, name), block);
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل خامات التقدم (Soul/Crystal/Blood/Energy)");
	}
}
