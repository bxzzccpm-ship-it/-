package net.xcvb.altar;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * مذبح السحر: بلوك تفاعلي يفتح شاشة صنع (Crafting) عادية، بس بشكل مخصص للمود.
 * هذا يخليه المكان الطبيعي اللي تصنع فيه كل وصفات XCVB المتقدمة (الأسلحة، الدروع،
 * الرونات، الحلقات...) بمكان وحد مميز بدل طاولة الصنع العادية.
 *
 * اخترنا نعيد استخدام شاشة الصنع الرسمية بالضبط (نفس شاشة طاولة الصنع)
 * عشان نضمن إنها تشتغل 100% بدون تعقيد إضافي أو خطر أخطاء ببناء شاشة Crafting مخصصة بالكامل.
 */
public class ArcaneAltarBlock extends Block {

	public ArcaneAltarBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world.isClient) {
			return ActionResult.SUCCESS;
		}

		player.openHandledScreen(state.createScreenHandlerFactory(world, pos));
		return ActionResult.CONSUME;
	}

	@Override
	public NamedScreenHandlerFactory createScreenHandlerFactory(BlockState state, World world, BlockPos pos) {
		return new NamedScreenHandlerFactory() {
			@Override
			public Text getDisplayName() {
				return Text.translatable("block.xcvb.arcane_altar");
			}

			@Override
			public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
				return new net.minecraft.screen.CraftingScreenHandler(syncId, inv,
						ScreenHandlerContext.create(world, pos));
			}
		};
	}
}
