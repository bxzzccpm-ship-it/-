package net.xcvb;

import net.fabricmc.api.ModInitializer;
import net.xcvb.registry.ModBlocks;
import net.xcvb.registry.ModItemGroups;
import net.xcvb.registry.ModItems;
import net.xcvb.registry.ModRings;
import net.xcvb.registry.ModRunes;
import net.xcvb.event.AmuletTickHandler;
import net.xcvb.event.ArmorSetBonusHandler;
import net.xcvb.ring.ModScreenHandlers;
import net.xcvb.ring.RingEffectHandler;
import net.xcvb.rune.RuneCombatHandler;
import net.xcvb.progression.ModOreBlocks;
import net.xcvb.progression.ModProgressionArmor;
import net.xcvb.progression.ModProgressionItems;
import net.xcvb.progression.ProgressionArmorAbilityHandler;
import net.xcvb.plant.ModPlantBlocks;
import net.xcvb.potion.CustomEffectHandler;
import net.xcvb.potion.ModPotions;
import net.xcvb.potion.ModStatusEffects;
import net.xcvb.skill.SkillEventHandler;
import net.xcvb.machine.ModMachineBlocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Xcvb implements ModInitializer {
	public static final String MOD_ID = "xcvb";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("XCVB Magic Mod: تحميل...");

		ModItems.registerItems();
		ModBlocks.registerBlocks();
		ModRunes.registerRunes();
		ModRings.registerRings();
		ModScreenHandlers.register();

		// === التوسعة الكبيرة: معادن + دروع + نباتات + جرعات + مهارات + آلات ===
		ModOreBlocks.register();
		ModProgressionItems.register();
		ModProgressionArmor.register();
		ModPlantBlocks.register();
		ModStatusEffects.register();
		ModPotions.register();
		ModPotions.registerBrewing();
		ModMachineBlocks.register();

		ModItemGroups.registerItemGroups();

		AmuletTickHandler.register();
		ArmorSetBonusHandler.register();
		RuneCombatHandler.register();
		RingEffectHandler.register();
		ProgressionArmorAbilityHandler.register();
		CustomEffectHandler.register();
		SkillEventHandler.register();

		LOGGER.info("XCVB Magic Mod: تم التحميل بنجاح!");
	}
}
