package net.xcvb.potion;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;

import java.util.List;

/**
 * تأثيراتنا الخمسة الأساسية (StatusEffect) وحدها ما تسوي شي بالماين كرافت، هي بس علامة.
 * هذا الكلاس هو اللي كيفعّل القدرة الحقيقية كل تيك وقت التأثير شغال على اللاعب.
 */
public class CustomEffectHandler {

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(CustomEffectHandler::onTick);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(CustomEffectHandler::onAfterDamage);
	}

	private static void onTick(MinecraftServer server) {
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {

			// جرعة الطيران: تفعّل قدرة الطيران الحقيقية طول ما التأثير شغال
			boolean hasFlight = player.hasStatusEffect(ModStatusEffects.FLIGHT);
			if (hasFlight && !player.getAbilities().allowFlying) {
				player.getAbilities().allowFlying = true;
				player.sendAbilitiesUpdate();
			} else if (!hasFlight && player.getAbilities().allowFlying && !player.isCreative() && !player.isSpectator()) {
				player.getAbilities().allowFlying = false;
				player.getAbilities().flying = false;
				player.sendAbilitiesUpdate();
			}

			// جرعة الشبح: الوحوش ما تشوفك (نطبق Invisibility الحقيقي بالخلفية)
			if (player.hasStatusEffect(ModStatusEffects.SPECTRAL)) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 40, 0, true, false));
			}

			// جرعة إبطاء الزمن: كل المخلوقات القريبة تتبطأ
			if (player.hasStatusEffect(ModStatusEffects.TIME_SLOW)) {
				ServerWorld world = player.getServerWorld();
				Box area = player.getBoundingBox().expand(10);
				List<LivingEntity> nearby = world.getEntitiesByClass(LivingEntity.class, area,
						e -> e != player && e instanceof HostileEntity);
				for (LivingEntity entity : nearby) {
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 3, true, false));
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 40, 3, true, false));
				}
			}
		}
	}

	private static void onAfterDamage(LivingEntity entity, DamageSource source, float baseDamageTaken,
			float damageTaken, boolean blocked) {
		// جرعة الامتصاص: اللاعب اللي شارب الجرعة يمتص صحة من الوحش اللي يضربه
		if (source.getAttacker() instanceof ServerPlayerEntity attacker
				&& attacker.hasStatusEffect(ModStatusEffects.LIFE_DRAIN)
				&& damageTaken > 0) {
			attacker.heal(damageTaken * 0.35F);
		}
	}
}
