package net.xcvb.potion;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

/**
 * خمس تأثيرات مخصصة. المنطق الفعلي (طيران، إخفاء عن الوحوش...) مطبق بـ CustomEffectHandler
 * لأن StatusEffect وحدها بالماين كرافت بترجع بس Attributes، القدرات الخاصة محتاجة كود تفعيل يدوي بالـ tick.
 */
public class ModStatusEffects {

	public static final RegistryEntry<StatusEffect> FLIGHT = register("flight",
			new StatusEffect(StatusEffectCategory.BENEFICIAL, 0x88CCFF) {});

	public static final RegistryEntry<StatusEffect> SPECTRAL = register("spectral",
			new StatusEffect(StatusEffectCategory.BENEFICIAL, 0xCCCCFF) {});

	public static final RegistryEntry<StatusEffect> LIFE_DRAIN = register("life_drain",
			new StatusEffect(StatusEffectCategory.BENEFICIAL, 0x8B0000) {});

	public static final RegistryEntry<StatusEffect> TIME_SLOW = register("time_slow",
			new StatusEffect(StatusEffectCategory.NEUTRAL, 0x444488) {});

	public static final RegistryEntry<StatusEffect> ENERGY_CHARGE = register("energy_charge",
			new StatusEffect(StatusEffectCategory.BENEFICIAL, 0xFFDD00) {});

	private static RegistryEntry<StatusEffect> register(String name, StatusEffect effect) {
		return RegistryEntry.of(Registry.register(Registries.STATUS_EFFECT, Identifier.of(Xcvb.MOD_ID, name), effect));
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل تأثيرات السحر (طيران/شبح/امتصاص/إبطاء الزمن/طاقة)");
	}
}
