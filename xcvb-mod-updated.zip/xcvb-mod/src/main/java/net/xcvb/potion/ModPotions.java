package net.xcvb.potion;

import net.fabricmc.fabric.api.recipe.v1.brewing.FabricBrewingRecipeRegistryBuilder;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;
import net.xcvb.progression.ModProgressionItems;

/**
 * خمس جرعات جديدة، كلها تصنع من "جرعة سميكة" (Awkward Potion) + مكون خاص بمذبح التخمير العادي،
 * تماماً مثل جرعات الماين كرافت الأصلية. الاسم يظهر تلقائياً بالعربي من ملف lang.
 */
public class ModPotions {

	public static final RegistryEntry<Potion> FLIGHT_POTION = register("flight_potion",
			new StatusEffectInstance(ModStatusEffects.FLIGHT, 3600, 0));

	public static final RegistryEntry<Potion> SPECTRAL_POTION = register("spectral_potion",
			new StatusEffectInstance(ModStatusEffects.SPECTRAL, 2400, 0));

	public static final RegistryEntry<Potion> LIFE_DRAIN_POTION = register("life_drain_potion",
			new StatusEffectInstance(ModStatusEffects.LIFE_DRAIN, 1800, 0));

	public static final RegistryEntry<Potion> TIME_SLOW_POTION = register("time_slow_potion",
			new StatusEffectInstance(ModStatusEffects.TIME_SLOW, 600, 0));

	public static final RegistryEntry<Potion> ENERGY_POTION = register("energy_potion",
			new StatusEffectInstance(ModStatusEffects.ENERGY_CHARGE, 1200, 0));

	private static RegistryEntry<Potion> register(String name, StatusEffectInstance effect) {
		Potion potion = new Potion(name, new StatusEffectInstance[]{effect});
		return RegistryEntry.of(Registry.register(Registries.POTION, Identifier.of(Xcvb.MOD_ID, name), potion));
	}

	public static void registerBrewing() {
		// جرعة سميكة + مكون -> جرعتنا (نفس أسلوب صنع جرعات الماين كرافت الأصلية)
		FabricBrewingRecipeRegistryBuilder.BUILD.register(builder -> {
			builder.addMix(Potions.AWKWARD, Items.PHANTOM_MEMBRANE, FLIGHT_POTION);
			builder.addMix(Potions.AWKWARD, Items.ENDER_PEARL, SPECTRAL_POTION);
			builder.addMix(Potions.AWKWARD, ModProgressionItems.BLOOD_SHARD, LIFE_DRAIN_POTION);
			builder.addMix(Potions.AWKWARD, Items.CLOCK, TIME_SLOW_POTION);
			builder.addMix(Potions.AWKWARD, ModProgressionItems.ENERGY_CELL, ENERGY_POTION);
		});

		Xcvb.LOGGER.info("XCVB: تسجيل وصفات تخمير الجرعات الجديدة");
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل الجرعات (طيران/شبح/امتصاص/إبطاء زمن/طاقة)");
	}
}
