package net.xcvb.skill;

import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

/**
 * مكافآت ثابتة تتفعل أول ما توصل لمستوى معين (وتبقى مفعّلة بعدها).
 * القتال: +ضرر بمستوى 10، الكريتيكال الإضافي بمستوى 30/50 مطبق بـ SkillCombatHandler.
 * التعدين: سرعة تعدين (Haste) مستوى 20، فرصة إسقاط مضاعف مطبقة بـ SkillMiningHandler.
 */
public class SkillRewards {

	public static void onLevelUp(ServerPlayerEntity player, SkillType type, int level) {
		if (type == SkillType.COMBAT) {
			if (level == 10) applyAttackBonus(player, 0.05); // 5%~ ضرر إضافي (تقريبي)
			if (level == 30) applyAttackBonus(player, 0.10);
			if (level == 50) applyAttackBonus(player, 0.20);
		}

		if (type == SkillType.MINING && level == 20) {
			player.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
					net.minecraft.entity.effect.StatusEffects.HASTE, 999999, 0, true, false));
		}
	}

	private static void applyAttackBonus(ServerPlayerEntity player, double amount) {
		EntityAttributeInstance instance = player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
		if (instance == null) return;

		Identifier id = Identifier.of(Xcvb.MOD_ID, "combat_skill_bonus_" + (int) (amount * 100));
		EntityAttributeModifier modifier = new EntityAttributeModifier(id, amount,
				EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);

		if (instance.getModifier(id) == null) {
			instance.addPersistentModifier(modifier);
		}
	}
}
