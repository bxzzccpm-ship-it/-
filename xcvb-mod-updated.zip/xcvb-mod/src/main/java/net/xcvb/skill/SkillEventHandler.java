package net.xcvb.skill;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Hand;
import net.xcvb.registry.ModItems;

/**
 * يربط كل الأحداث اللي كتزيد نقاط المهارات:
 * قتال (قتل مخلوق) - تعدين (كسر بلوك) - كيمياء (شرب جرعة) - سحر (استخدام أداة سحرية)
 */
public class SkillEventHandler {

	public static void register() {
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
			DamageSource source = damageSource;
			if (source.getAttacker() instanceof ServerPlayerEntity player) {
				PlayerSkillManager.addXp(player, SkillType.COMBAT, 12);
			}
		});

		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (player instanceof ServerPlayerEntity serverPlayer) {
				PlayerSkillManager.addXp(serverPlayer, SkillType.MINING, 4);

				// مستوى تعدين 30+: فرصة إسقاط مضاعف
				int level = PlayerSkillManager.getLevel(serverPlayer, SkillType.MINING);
				if (level >= 30 && Math.random() < 0.15) {
					ItemStack drop = new ItemStack(state.getBlock().asItem());
					if (!drop.isEmpty()) {
						net.minecraft.entity.ItemEntity extra = new net.minecraft.entity.ItemEntity(
								world, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, drop);
						world.spawnEntity(extra);
					}
				}
			}
		});

		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) {
				return TypedActionResult.pass(player.getStackInHand(hand));
			}

			ItemStack stack = player.getStackInHand(hand);

			if (stack.getItem() instanceof PotionItem) {
				PlayerSkillManager.addXp(serverPlayer, SkillType.ALCHEMY, 8);
			}

			if (isMagicItem(stack)) {
				PlayerSkillManager.addXp(serverPlayer, SkillType.MAGIC, 6);
			}

			return TypedActionResult.pass(stack);
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			PlayerSkillManager.sendSummary(handler.getPlayer());
		});
	}

	private static boolean isMagicItem(ItemStack stack) {
		return stack.isOf(ModItems.STAFF_OF_STORMS)
				|| stack.isOf(ModItems.WAND_OF_TELEPORTATION)
				|| stack.isOf(ModItems.FROST_WAND)
				|| stack.isOf(ModItems.FIRE_SCROLL)
				|| stack.isOf(ModItems.METEOR_HAMMER);
	}
}
