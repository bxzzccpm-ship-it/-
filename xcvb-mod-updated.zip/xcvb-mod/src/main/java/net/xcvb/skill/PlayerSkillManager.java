package net.xcvb.skill;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * نظام مهارات بسيط: كل لاعب يبدأ من المستوى 1 بكل مهارة، وكل ما يسوي الفعل المرتبط
 * (قتال/تعدين/كيمياء/سحر) تزيد نقاطه، ووقت توصل لعتبة معينة يطلع مستوى ومعاه مكافأة.
 *
 * ملاحظة مهمة: هذا التخزين بالذاكرة (RAM) فقط - يعني إذا السيرفر عاد تشغيل أو اللاعب
 * خرج ودخل عالم جديد، الأرقام ترجع للبداية. إذا تبي حفظ دائم (يبقى بعد إعادة التشغيل)
 * قولّي ونضيفوه بمرحلة جاية، محتاج نظام تخزين NBT إضافي.
 */
public class PlayerSkillManager {

	private static final Map<UUID, EnumMap<SkillType, Integer>> LEVELS = new HashMap<>();
	private static final Map<UUID, EnumMap<SkillType, Integer>> XP = new HashMap<>();

	private static final int BASE_XP_PER_LEVEL = 100;

	public static int getLevel(ServerPlayerEntity player, SkillType type) {
		return LEVELS.computeIfAbsent(player.getUuid(), u -> freshMap()).getOrDefault(type, 1);
	}

	public static int getXp(ServerPlayerEntity player, SkillType type) {
		return XP.computeIfAbsent(player.getUuid(), u -> freshMap()).getOrDefault(type, 0);
	}

	public static void addXp(ServerPlayerEntity player, SkillType type, int amount) {
		EnumMap<SkillType, Integer> xpMap = XP.computeIfAbsent(player.getUuid(), u -> freshMap());
		EnumMap<SkillType, Integer> lvlMap = LEVELS.computeIfAbsent(player.getUuid(), u -> freshMap());

		int currentXp = xpMap.getOrDefault(type, 0) + amount;
		int currentLevel = lvlMap.getOrDefault(type, 1);
		int needed = requiredXp(currentLevel);

		boolean leveledUp = false;
		while (currentXp >= needed) {
			currentXp -= needed;
			currentLevel++;
			needed = requiredXp(currentLevel);
			leveledUp = true;
		}

		xpMap.put(type, currentXp);
		lvlMap.put(type, currentLevel);

		if (leveledUp) {
			player.sendMessage(Text.literal("⭐ مهارة " + type.arabicName + " صعدت لمستوى " + currentLevel)
					.formatted(Formatting.GOLD), true);
			SkillRewards.onLevelUp(player, type, currentLevel);
		}
	}

	private static int requiredXp(int level) {
		return BASE_XP_PER_LEVEL + (level - 1) * 40;
	}

	private static EnumMap<SkillType, Integer> freshMap() {
		return new EnumMap<>(SkillType.class);
	}

	public static void sendSummary(ServerPlayerEntity player) {
		StringBuilder sb = new StringBuilder("§b== مستويات مهاراتك ==");
		for (SkillType type : SkillType.values()) {
			sb.append("\n§7").append(type.arabicName).append(": §f").append(getLevel(player, type));
		}
		player.sendMessage(Text.literal(sb.toString()), false);
	}
}
