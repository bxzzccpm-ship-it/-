package net.xcvb.skill;

public enum SkillType {
	COMBAT("القتال"),
	MINING("التعدين"),
	ALCHEMY("الكيمياء"),
	MAGIC("السحر");

	public final String arabicName;

	SkillType(String arabicName) {
		this.arabicName = arabicName;
	}
}
