package net.xcvb.totem.mixin;

import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.xcvb.totem.ModItems;
import net.xcvb.totem.TotemTier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hooks into LivingEntity#tryUseTotem, the exact same method vanilla uses for the
 * normal Totem of Undying. We only act when the entity is holding one of the three
 * XCVB totems; otherwise this mixin does nothing and vanilla behaves exactly as before.
 * This avoids touching/overriding any vanilla item logic, so it should not conflict
 * with other mods that don't also mixin into this same method.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "tryUseTotem", at = @At("HEAD"), cancellable = true)
    private void xcvbtotem$tryUseTotem(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;

        Hand usedHand = null;
        TotemTier tier = null;

        for (Hand hand : Hand.values()) {
            ItemStack stack = self.getStackInHand(hand);
            TotemTier found = tierOf(stack);
            if (found != null) {
                usedHand = hand;
                tier = found;
                break;
            }
        }

        // Not holding an XCVB totem in either hand: let vanilla logic (or the real
        // Totem of Undying) run completely untouched.
        if (tier == null) {
            return;
        }

        ItemStack usedStack = self.getStackInHand(usedHand);

        if (!self.getWorld().isClient) {
            self.setHealth(1.0F);
            tier.getEffects().forEach(self::addStatusEffect);

            // Vanilla's own tryUseTotem() would normally fire this criterion itself, but we
            // cancel that method entirely (see below) since our items aren't the vanilla totem,
            // so we fire it manually. This is what lets advancements built on the vanilla
            // "minecraft:used_totem" trigger work for our items too (e.g. the Supreme achievement).
            if (self instanceof ServerPlayerEntity serverPlayer) {
                Criteria.USED_TOTEM.trigger(serverPlayer, usedStack);
            }

            // 35 is the vanilla network status id for "play totem of undying effect".
            // It is stable across versions and works for any item, not just the vanilla totem.
            self.getWorld().sendEntityStatus(self, (byte) 35);

            // Play ONLY our own "grand" sound for this tier - no vanilla totem ping at all.
            SoundEvent triggerSound = tier.getExtraSound() != null ? tier.getExtraSound() : SoundEvents.ITEM_TOTEM_USE;
            self.getWorld().playSound(
                    null,
                    self.getX(), self.getY(), self.getZ(),
                    triggerSound,
                    SoundCategory.PLAYERS,
                    1.0F, 1.0F
            );

            if (self.getWorld() instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(
                        tier.getParticle(),
                        self.getX(), self.getY() + self.getHeight() / 2.0, self.getZ(),
                        tier.getParticleCount(),
                        0.5, 0.5, 0.5,
                        0.05
                );

                // Also burst actual icons of OUR item (not the vanilla totem) around the player,
                // so the pop-up visibly shows the correct XCVB tier regardless of what the small
                // built-in HUD totem icon renders.
                serverWorld.spawnParticles(
                        new ItemStackParticleEffect(ParticleTypes.ITEM, usedStack.copyWithCount(1)),
                        self.getX(), self.getY() + self.getHeight() / 2.0, self.getZ(),
                        16,
                        0.4, 0.4, 0.4,
                        0.15
                );
            }

            if (self instanceof PlayerEntity player && !player.getAbilities().creativeMode) {
                usedStack.decrement(1);

                // Auto-refill: move the strongest XCVB totem left in the inventory (any tier)
                // straight into the hand slot that just emptied.
                if (usedStack.isEmpty()) {
                    refillFromInventory(player, usedHand, tier);
                }
            }
        }

        cir.setReturnValue(true);
        cir.cancel();
    }

    /**
     * Auto-refill: after a totem empties, look through the player's inventory for ANY
     * other XCVB totem (any tier) and equip it - preferring the STRONGEST tier available,
     * not just a match of the exact same tier that was just used.
     */
    private static void refillFromInventory(PlayerEntity player, Hand emptiedHand, TotemTier usedTier) {
        PlayerInventory inventory = player.getInventory();

        int bestSlot = -1;
        TotemTier bestTier = null;

        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            TotemTier found = tierOf(stack);
            if (found != null && (bestTier == null || found.ordinal() > bestTier.ordinal())) {
                bestSlot = i;
                bestTier = found;
            }
        }

        if (bestSlot == -1) {
            return;
        }

        ItemStack found = inventory.getStack(bestSlot);
        found.decrement(1);
        player.setStackInHand(emptiedHand, new ItemStack(ModItems.itemForTier(bestTier)));
    }

    private static TotemTier tierOf(ItemStack stack) {
        if (stack.isEmpty()) return null;
        if (stack.isOf(ModItems.TOTEM_XCVB_SIMPLE)) return TotemTier.SIMPLE;
        if (stack.isOf(ModItems.TOTEM_XCVB_MEDIUM)) return TotemTier.MEDIUM;
        if (stack.isOf(ModItems.TOTEM_XCVB_STRONG)) return TotemTier.STRONG;
        if (stack.isOf(ModItems.TOTEM_XCVB_SUPREME)) return TotemTier.SUPREME;
        return null;
    }
}
