package net.xcvb.totem;

import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradedItem;
import net.minecraft.village.VillagerProfession;

/**
 * Adds one villager trade: a level-3 (Journeyman) Cleric sells a Simple XCVB totem for
 * 20 emeralds. Built entirely on Fabric API's TradeOfferHelper, no mixin involved.
 *
 * NOTE: this is the part of this update least likely to have exactly the right API shape,
 * since villager trade constructors have changed a couple of times across Minecraft
 * versions. If ./gradlew build fails specifically in this file, either paste me the error
 * or just delete this file and remove the one "ModTrades.register();" line from
 * XcvbTotemMod.java - nothing else in the mod depends on this class.
 */
public class ModTrades {

    public static void register() {
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CLERIC, 3, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.EMERALD, 20),
                    new ItemStack(ModItems.TOTEM_XCVB_SIMPLE),
                    3,   // max uses before the villager needs to restock
                    10,  // experience given to the villager
                    0.05f // price multiplier (demand-based price drift)
            ));
        });
    }
}
