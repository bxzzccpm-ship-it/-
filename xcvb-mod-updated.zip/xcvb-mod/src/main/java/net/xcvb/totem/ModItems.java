package net.xcvb.totem;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;

public class ModItems {

    // Short effect summary shown in the item's tooltip (visible in the inventory AND in
    // JEI's item info panel/recipe view) so players can see what a tier does before they
    // craft it, without needing a wiki. Pure data via the item's default LORE component -
    // no mixin, no rendering hook, so this can't conflict with anything else.
    public static final Item TOTEM_XCVB_SIMPLE = register(TotemTier.SIMPLE.itemId,
            withLore(new Item.Settings().maxCount(1),
                    "On death: Regeneration II, Absorption I, Fire Resistance"));
    public static final Item TOTEM_XCVB_MEDIUM = register(TotemTier.MEDIUM.itemId,
            withLore(new Item.Settings().maxCount(1),
                    "On death: Regeneration III, Absorption II, Fire Resistance+"));
    public static final Item TOTEM_XCVB_STRONG = register(TotemTier.STRONG.itemId,
            withLore(new Item.Settings().maxCount(1),
                    "On death: Regeneration IV, Absorption III, Fire Resistance++"));
    public static final Item TOTEM_XCVB_SUPREME = register(TotemTier.SUPREME.itemId,
            withLore(new Item.Settings().maxCount(1),
                    "On death: Regeneration V, Absorption IV, Fire Resistance+++"));

    private static Item register(String path, Item.Settings settings) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of("xcvbtotem", path));
        Item item = new Item(settings.registryKey(key));
        return Registry.register(Registries.ITEM, key, item);
    }

    private static Item.Settings withLore(Item.Settings settings, String... lines) {
        List<Text> lore = List.of(lines).stream()
                .map(line -> (Text) Text.literal(line).formatted(Formatting.GRAY))
                .toList();
        return settings.component(DataComponentTypes.LORE, new LoreComponent(lore));
    }

    public static Item itemForTier(TotemTier tier) {
        return switch (tier) {
            case SIMPLE -> TOTEM_XCVB_SIMPLE;
            case MEDIUM -> TOTEM_XCVB_MEDIUM;
            case STRONG -> TOTEM_XCVB_STRONG;
            case SUPREME -> TOTEM_XCVB_SUPREME;
        };
    }

    public static void register() {
        // Put the four totems in the combat creative tab, right after the vanilla totem of undying.
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(TOTEM_XCVB_SIMPLE);
            entries.add(TOTEM_XCVB_MEDIUM);
            entries.add(TOTEM_XCVB_STRONG);
            entries.add(TOTEM_XCVB_SUPREME);
        });
    }
}
