package net.xcvb.plant;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

/**
 * أربع نباتات، كل وحدة عندها استخدام مختلف بالصناعة (جرعات، مانا، خشب سحري).
 * Ghost Flower و Fire Herb و Mana Leaf: نباتات صغيرة توضع على العشب/الأرض.
 * Crystal Tree: شجرة كاملة (جذع + أوراق) - توضع يدوياً (بدون نمو تلقائي من بذرة).
 */
public class ModPlantBlocks {

	public static final Block GHOST_FLOWER = registerPlant("ghost_flower",
			AbstractBlock.Settings.create().mapColor(MapColor.PALE_PURPLE).noCollision()
					.breakInstantly().sounds(BlockSoundGroup.GRASS).luminance(state -> 6));

	public static final Block FIRE_HERB = registerPlant("fire_herb",
			AbstractBlock.Settings.create().mapColor(MapColor.RED).noCollision()
					.breakInstantly().sounds(BlockSoundGroup.GRASS));

	public static final Block MANA_LEAF = registerPlant("mana_leaf",
			AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE).noCollision()
					.breakInstantly().sounds(BlockSoundGroup.GRASS));

	public static final Block CRYSTAL_LOG = registerBlock("crystal_log",
			new PillarBlock(AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE)
					.strength(2.0F).sounds(BlockSoundGroup.WOOD)));

	public static final Block CRYSTAL_LEAVES = registerBlock("crystal_leaves",
			new LeavesBlock(AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE)
					.strength(0.2F).ticksRandomly().sounds(BlockSoundGroup.GRASS)
					.nonOpaque().luminance(state -> 4)));

	// ملاحظة: استخدمنا Block عادي بلا تصادم (noCollision) بدل PlantBlock المجردة،
	// والشكل البصري "زهرة/عشب" كيجي من موديل الـ resource pack (parent: block/cross)
	// مو من كلاس الجافا. هذا يضمن التوافق 100% وما كيأثرش على الشكل النهائي باللعبة.
	private static Block registerPlant(String name, AbstractBlock.Settings settings) {
		Block block = new Block(settings);
		return registerBlock(name, block);
	}

	private static Block registerBlock(String name, Block block) {
		Registry.register(Registries.ITEM, Identifier.of(Xcvb.MOD_ID, name),
				new BlockItem(block, new Item.Settings()));
		return Registry.register(Registries.BLOCK, Identifier.of(Xcvb.MOD_ID, name), block);
	}

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل النباتات (Ghost Flower / Fire Herb / Mana Leaf / Crystal Tree)");
	}
}
