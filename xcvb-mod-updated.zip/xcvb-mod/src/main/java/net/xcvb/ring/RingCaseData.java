package net.xcvb.ring;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * علبة الحلقات (Ring Case) تخزن نوعين من الحلقات (سلوت 0 وسلوت 1) داخل بيانات
 * العنصر نفسه (Custom Data Component). أينما راح العنصر بالحقيبة، الحلقات تروح وياه.
 */
public class RingCaseData {

	public static Item getRing(ItemStack caseStack, int slot) {
		NbtComponent component = caseStack.get(DataComponentTypes.CUSTOM_DATA);
		if (component == null) return null;

		NbtCompound nbt = component.copyNbt();
		String key = "ring" + slot;
		if (!nbt.contains(key)) return null;

		Identifier id = Identifier.tryParse(nbt.getString(key));
		if (id == null) return null;

		Item item = Registries.ITEM.get(id);
		return item == Items.AIR ? null : item;
	}

	public static void setRing(ItemStack caseStack, int slot, Item ring) {
		NbtComponent component = caseStack.get(DataComponentTypes.CUSTOM_DATA);
		NbtCompound nbt = component != null ? component.copyNbt() : new NbtCompound();

		String key = "ring" + slot;
		if (ring == null) {
			nbt.remove(key);
		} else {
			nbt.putString(key, Registries.ITEM.getId(ring).toString());
		}

		caseStack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
	}
}
