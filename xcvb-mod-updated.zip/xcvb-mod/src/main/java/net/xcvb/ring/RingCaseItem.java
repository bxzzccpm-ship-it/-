package net.xcvb.ring;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * علبة الحلقات: احتفظ فيها بجيبك (أي مكان) عشان الحلقات جواها تشتغل تلقائيًا.
 * اضغط يمين لفتح شاشة صغيرة فيها سلوتين تحط فيهم الحلقات اللي تبيها.
 */
public class RingCaseItem extends Item {

	public RingCaseItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (!world.isClient) {
			user.openHandledScreen(new NamedScreenHandlerFactory() {
				@Override
				public Text getDisplayName() {
					return Text.translatable("item.xcvb.ring_case");
				}

				@Override
				public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
					return new RingCaseScreenHandler(syncId, inv, new RingInventory(stack));
				}
			});
		}

		return TypedActionResult.success(stack, world.isClient());
	}
}
