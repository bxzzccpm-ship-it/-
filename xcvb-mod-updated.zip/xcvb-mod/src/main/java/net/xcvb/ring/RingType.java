package net.xcvb.ring;

public enum RingType {
	STRENGTH,   // ضرر إضافي بالهجوم
	HASTE,      // سرعة تعدين
	FEATHER,    // بدون ضرر سقوط
	REGROWTH,   // شفاء تلقائي بطيء
	SWIFTNESS   // سرعة حركة
}
