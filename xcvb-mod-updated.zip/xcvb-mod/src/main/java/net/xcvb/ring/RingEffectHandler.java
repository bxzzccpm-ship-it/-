package net.xcvb.ring;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashSet;
import java.util.Set;

public class RingEffectHandler {

	private static final int CHECK_INTERVAL = 20; // كل ثانية

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(RingEffectHandler::onServerTick);
	}

	private static void onServerTick(MinecraftServer server) {
		if (server.getTicks() % CHECK_INTERVAL != 0) return;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			Set<RingType> equipped = new HashSet<>();

			for (ItemStack stack : player.getInventory().main) {
				collectRings(stack, equipped);
			}
			collectRings(player.getOffHandStack(), equipped);

			if (equipped.contains(RingType.SWIFTNESS)) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 0, true, false));
			}
			if (equipped.contains(RingType.HASTE)) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 40, 1, true, false));
			}
			if (equipped.contains(RingType.FEATHER)) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 40, 0, true, false));
			}
			if (equipped.contains(RingType.REGROWTH) && player.getHealth() < player.getMaxHealth()) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 0, true, false));
			}
			// STRENGTH (ضرر إضافي) تنطبق مباشرة بمعالج الهجوم بمود الرونات - نستخدم نفس الفكرة هنا:
			if (equipped.contains(RingType.STRENGTH)) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 0, true, false));
			}
		}
	}

	private static void collectRings(ItemStack stack, Set<RingType> out) {
		if (stack.isEmpty() || !(stack.getItem() instanceof RingCaseItem)) return;

		for (int i = 0; i < 2; i++) {
			Item ring = RingCaseData.getRing(stack, i);
			if (ring instanceof RingItem ringItem) {
				out.add(ringItem.getType());
			}
		}
	}
}
