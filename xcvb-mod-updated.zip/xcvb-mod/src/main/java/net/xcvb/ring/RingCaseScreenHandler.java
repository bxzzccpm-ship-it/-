package net.xcvb.ring;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

public class RingCaseScreenHandler extends ScreenHandler {

	private final Inventory ringInventory;

	// يستخدم بالعميل لما يوصل باكيت فتح الشاشة (بدون بيانات إضافية)
	public RingCaseScreenHandler(int syncId, PlayerInventory playerInventory) {
		this(syncId, playerInventory, new SimpleInventory(2));
	}

	// يستخدم بالسيرفر لما نفتح الشاشة فعليًا مع مخزون الحلقات الحقيقي
	public RingCaseScreenHandler(int syncId, PlayerInventory playerInventory, Inventory ringInventory) {
		super(ModScreenHandlers.RING_CASE_SCREEN_HANDLER, syncId);
		this.ringInventory = ringInventory;
		checkSize(ringInventory, 2);
		ringInventory.onOpen(playerInventory.player);

		// سلوتين الحلقات - يقبلون بس عناصر من نوع RingItem
		this.addSlot(new Slot(ringInventory, 0, 62, 24) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.getItem() instanceof RingItem;
			}
		});
		this.addSlot(new Slot(ringInventory, 1, 98, 24) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.getItem() instanceof RingItem;
			}
		});

		// جيب اللاعب (3 صفوف)
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 51 + row * 18));
			}
		}
		// شريط الأدوات السريع (Hotbar)
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 109));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return ringInventory.canPlayerUse(player);
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		ItemStack result = ItemStack.EMPTY;
		Slot slot = this.slots.get(index);

		if (slot != null && slot.hasStack()) {
			ItemStack original = slot.getStack();
			result = original.copy();

			if (index < 2) {
				// من سلوت الحلقة -> لجيب اللاعب
				if (!this.insertItem(original, 2, this.slots.size(), true)) {
					return ItemStack.EMPTY;
				}
			} else {
				// من جيب اللاعب -> لسلوت الحلقة (إذا كان العنصر حلقة)
				if (original.getItem() instanceof RingItem) {
					if (!this.insertItem(original, 0, 2, false)) {
						return ItemStack.EMPTY;
					}
				} else {
					return ItemStack.EMPTY;
				}
			}

			if (original.isEmpty()) {
				slot.setStack(ItemStack.EMPTY);
			} else {
				slot.markDirty();
			}
		}

		return result;
	}

	@Override
	public void onClosed(PlayerEntity player) {
		super.onClosed(player);
		ringInventory.onClose(player);
	}
}
