package net.xcvb.ring;

import net.minecraft.item.Item;

public class RingItem extends Item {

	private final RingType type;

	public RingItem(RingType type, Settings settings) {
		super(settings);
		this.type = type;
	}

	public RingType getType() {
		return type;
	}
}
