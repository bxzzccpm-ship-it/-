package net.xcvb.ring;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;

public class RingInventory extends SimpleInventory {

	private final ItemStack caseStack;

	public RingInventory(ItemStack caseStack) {
		super(2);
		this.caseStack = caseStack;

		for (int i = 0; i < 2; i++) {
			var ring = RingCaseData.getRing(caseStack, i);
			if (ring != null) {
				this.setStack(i, new ItemStack(ring));
			}
		}
	}

	@Override
	public void markDirty() {
		super.markDirty();
		for (int i = 0; i < 2; i++) {
			ItemStack stack = this.getStack(i);
			RingCaseData.setRing(caseStack, i, stack.isEmpty() ? null : stack.getItem());
		}
	}
}
