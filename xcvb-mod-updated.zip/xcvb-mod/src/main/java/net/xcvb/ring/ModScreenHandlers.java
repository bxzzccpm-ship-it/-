package net.xcvb.ring;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;
import net.xcvb.Xcvb;

public class ModScreenHandlers {

	public static final ScreenHandlerType<RingCaseScreenHandler> RING_CASE_SCREEN_HANDLER = Registry.register(
			Registries.SCREEN_HANDLER,
			Identifier.of(Xcvb.MOD_ID, "ring_case"),
			new ScreenHandlerType<>(RingCaseScreenHandler::new, FeatureSet.empty()));

	public static void register() {
		Xcvb.LOGGER.info("XCVB: تسجيل واجهة علبة الحلقات");
	}
}
