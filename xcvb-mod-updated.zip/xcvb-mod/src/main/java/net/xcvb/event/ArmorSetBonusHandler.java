package net.xcvb.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.xcvb.registry.ModItems;

public class ArmorSetBonusHandler {

	private static final int CHECK_INTERVAL = 40; // كل ثانيتين

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(ArmorSetBonusHandler::onServerTick);
	}

	private static void onServerTick(MinecraftServer server) {
		if (server.getTicks() % CHECK_INTERVAL != 0) return;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			ItemStack head = player.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD);
			ItemStack chest = player.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST);
			ItemStack legs = player.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS);
			ItemStack feet = player.getEquippedStack(net.minecraft.entity.EquipmentSlot.FEET);

			boolean fullSet = head.isOf(ModItems.ARCANITE_HELMET)
					&& chest.isOf(ModItems.ARCANITE_CHESTPLATE)
					&& legs.isOf(ModItems.ARCANITE_LEGGINGS)
					&& feet.isOf(ModItems.ARCANITE_BOOTS);

			if (fullSet) {
				// مكافأة المجموعة الكاملة: سرعة حركة + مقاومة سقوط خفيفة
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 1, true, false));
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 60, 0, true, false));
			}
		}
	}
}
