package net.xcvb.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.xcvb.registry.ModItems;

public class AmuletTickHandler {

	private static final int CHECK_INTERVAL = 100; // كل 5 ثواني (20 tick = ثانية)

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(AmuletTickHandler::onServerTick);
	}

	private static void onServerTick(MinecraftServer server) {
		if (server.getTicks() % CHECK_INTERVAL != 0) return;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			boolean hasAmulet = player.getInventory().count(ModItems.AMULET_OF_VITALITY) > 0
					|| player.getOffHandStack().isOf(ModItems.AMULET_OF_VITALITY);

			if (hasAmulet && player.getHealth() < player.getMaxHealth()) {
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 0, true, true));
			}
		}
	}
}
